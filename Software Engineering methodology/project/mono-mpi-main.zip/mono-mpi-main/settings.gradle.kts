rootProject.name = "mono-mpi"
include("auth-service")
include("user-service")
include("cataclysm-service")
include("machine-service")
include("task-service")
include("timeline-service")
include("gateway-service")