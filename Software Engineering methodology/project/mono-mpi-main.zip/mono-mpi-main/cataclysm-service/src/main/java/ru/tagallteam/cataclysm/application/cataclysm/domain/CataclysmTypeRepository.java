package ru.tagallteam.cataclysm.application.cataclysm.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CataclysmTypeRepository extends JpaRepository<CataclysmType, Long> {
}
