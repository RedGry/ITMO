package ru.tagallteam.cataclysm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CataclysmServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(CataclysmServiceApplication.class, args);
    }

}
