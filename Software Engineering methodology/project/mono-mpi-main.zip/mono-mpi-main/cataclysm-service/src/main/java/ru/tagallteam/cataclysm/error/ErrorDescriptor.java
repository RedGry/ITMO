package ru.tagallteam.cataclysm.error;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.util.ObjectUtils;
import ru.tagallteam.cataclysm.error.exception.ApplicationException;
import ru.tagallteam.cataclysm.error.model.ApplicationError;

@Getter
@AllArgsConstructor
public enum ErrorDescriptor {

    CATACLYSM_TYPE_NOT_FOUND("Нет такого типа катаклизма", HttpStatus.NOT_FOUND),
    CATACLYSM_NOT_FOUND("Нет такого катаклизма", HttpStatus.NOT_FOUND),
    DATA_BASE_ERROR("Ошибка взаимодействия с бд", HttpStatus.BAD_REQUEST),
    INTERNAL_SERVER_ERROR("Неожиданная ошибка сервиса", HttpStatus.INTERNAL_SERVER_ERROR),
    NOT_FOUND("Запрошенный ресурс (интерфейс) не существует", HttpStatus.NOT_FOUND);


    private final String message;


    private final HttpStatus status;

    public void exception() {
        throw ApplicationException.of(applicationError());
    }

    public ApplicationException callExceptionModel() {
        return ApplicationException.of(applicationError());
    }

    public void throwIsTrue(Boolean flag) {
        if (flag) {
            exception();
        }
    }

    public void throwIsFalse(Boolean flag) {
        if (!flag) {
            exception();
        }
    }

    public void throwIsNull(Object object) {
        if (ObjectUtils.isEmpty(object)) {
            exception();
        }
    }

    public ApplicationError applicationError() {
        return new ApplicationError(this.message, this.status);
    }

}
