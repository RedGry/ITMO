package ru.tagallteam.cataclysm.application.cataclysm.model;

import lombok.Data;

@Data
public class CataclysmTypeDto {
    private Long id;
    private String name;
}
