package ru.tagallteam.cataclysm.application.cataclysm.mapper;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import ru.tagallteam.cataclysm.application.cataclysm.domain.Cataclysm;
import ru.tagallteam.cataclysm.application.cataclysm.domain.CataclysmType;
import ru.tagallteam.cataclysm.application.cataclysm.model.CataclysmCreateDto;
import ru.tagallteam.cataclysm.application.cataclysm.model.CataclysmDto;
import ru.tagallteam.cataclysm.application.cataclysm.model.CataclysmTypeDto;
import ru.tagallteam.cataclysm.configuration.timeline.service.TimelineService;
import ru.tagallteam.cataclysm.error.exception.ApplicationException;

@Slf4j
@Component
@AllArgsConstructor
public class CataclysmMapper {

    private final TimelineService timelineService;

    public Cataclysm convertToCataclysm(CataclysmCreateDto cataclysmCreateDto, CataclysmType cataclysmType) {
        Cataclysm cataclysm = new Cataclysm();
        cataclysm.setTimelineId(timelineService.createRandomTimeline().getId());
        cataclysm.setCataclysmType(cataclysmType);
        cataclysm.setPlace(cataclysmCreateDto.getPlace());
        cataclysm.setDescription(cataclysmCreateDto.getDescription());
        cataclysm.setTime(cataclysmCreateDto.getTime());
        return cataclysm;
    }

    public Cataclysm convertToCataclysm(Cataclysm cataclysm, CataclysmCreateDto cataclysmCreateDto,
                                        CataclysmType cataclysmType
    ) {
        Cataclysm updateCataclysm = new Cataclysm();
        updateCataclysm.setId(cataclysm.getId());
        updateCataclysm.setTimelineId(cataclysm.getTimelineId());
        updateCataclysm.setCataclysmType(cataclysmType);
        updateCataclysm.setPlace(cataclysmCreateDto.getPlace());
        updateCataclysm.setDescription(cataclysmCreateDto.getDescription());
        updateCataclysm.setTime(cataclysmCreateDto.getTime());
        return updateCataclysm;
    }

    public CataclysmDto convertToCataclysmDto(Cataclysm cataclysm) {
        CataclysmDto cataclysmDto = new CataclysmDto();
        try {
            cataclysmDto.setTimeline(timelineService.getTimeline(cataclysm.getTimelineId()));
        } catch (ApplicationException ignore) {}
        cataclysmDto.setId(cataclysm.getId());
        cataclysmDto.setPlace(cataclysm.getPlace());
        cataclysmDto.setDescription(cataclysm.getDescription());
        cataclysmDto.setTime(cataclysm.getTime());
        if (cataclysm.getCataclysmType() != null) {
            cataclysmDto.setType(convertToCataclysmTypeDto(cataclysm.getCataclysmType()));
        }
        return cataclysmDto;
    }

    public CataclysmTypeDto convertToCataclysmTypeDto(CataclysmType cataclysmType) {
        CataclysmTypeDto cataclysmTypeDto = new CataclysmTypeDto();
        cataclysmTypeDto.setId(cataclysmType.getId());
        cataclysmTypeDto.setName(cataclysmType.getName());
        return cataclysmTypeDto;
    }


}
