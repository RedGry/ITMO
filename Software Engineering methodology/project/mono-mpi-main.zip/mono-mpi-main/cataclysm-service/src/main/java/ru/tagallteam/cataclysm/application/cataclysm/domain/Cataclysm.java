package ru.tagallteam.cataclysm.application.cataclysm.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalTime;

@Getter
@Setter
@Entity
@ToString(of = "id")
@Table(name = "cataclysm")
public class Cataclysm {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence")
    @SequenceGenerator(name = "sequence", allocationSize = 1, sequenceName = "cataclysm_seq")
    private Long id;
    @ManyToOne
    @JoinColumn(name = "type_id")
    private CataclysmType cataclysmType;
    @Column(name = "timeline_id")
    private Long timelineId;
    @Column(name = "place")
    private String place;
    @Column(name = "time")
    private LocalTime time;
    @Column(name = "description")
    private String description;
}
