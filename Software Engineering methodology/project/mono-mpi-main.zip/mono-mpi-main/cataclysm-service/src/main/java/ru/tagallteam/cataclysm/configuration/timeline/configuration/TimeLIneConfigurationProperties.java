package ru.tagallteam.cataclysm.configuration.timeline.configuration;

import jakarta.annotation.PostConstruct;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Data
@Slf4j
@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "service.timeline-service")
public class TimeLIneConfigurationProperties {
    private String url;

    private Integer timout;

    @PostConstruct
    public void postConstructor() {
        log.info("""
                                
                \tinitialized TimeLIneConfiguration
                \turl: {}
                \ttimout: {}""", url, timout);
    }
}
