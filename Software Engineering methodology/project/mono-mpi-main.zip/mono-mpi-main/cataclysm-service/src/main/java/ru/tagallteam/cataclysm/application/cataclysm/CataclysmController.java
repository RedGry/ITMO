package ru.tagallteam.cataclysm.application.cataclysm;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.tagallteam.cataclysm.application.cataclysm.model.CataclysmCreateDto;
import ru.tagallteam.cataclysm.application.cataclysm.model.CataclysmDto;
import ru.tagallteam.cataclysm.application.cataclysm.service.CataclysmService;

import java.util.List;

@RestController
@AllArgsConstructor
@RequestMapping("/v1/cataclysm")
public class CataclysmController {

    private final CataclysmService cataclysmService;

    @PostMapping("")
    public CataclysmDto createCataclysm(@RequestBody CataclysmCreateDto cataclysmCreateDto) {
        return cataclysmService.createCataclysm(cataclysmCreateDto);
    }

    @GetMapping()
    public List<CataclysmDto> getCataclysms(@RequestParam Long page, @RequestParam Long limit) {
        return cataclysmService.getCataclysms(page, limit);
    }

    @GetMapping("/{cataclysmId}")
    public CataclysmDto getCataclysm(@PathVariable Long cataclysmId) {
        return cataclysmService.getCataclysm(cataclysmId);
    }

    @PutMapping("/{cataclysmId}")
    public CataclysmDto updateCataclysm(@PathVariable Long cataclysmId,
                                        @RequestBody CataclysmCreateDto cataclysmCreateDto
    ) {
        return cataclysmService.updateCataclysm(cataclysmId, cataclysmCreateDto);
    }

    @DeleteMapping("/{cataclysmId}")
    public void deleteCataclysm(@PathVariable Long cataclysmId) {
        cataclysmService.deleteCataclysm(cataclysmId);
    }
}
