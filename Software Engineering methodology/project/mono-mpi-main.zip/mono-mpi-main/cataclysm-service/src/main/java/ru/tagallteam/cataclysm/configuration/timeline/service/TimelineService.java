package ru.tagallteam.cataclysm.configuration.timeline.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import ru.tagallteam.cataclysm.configuration.timeline.model.RandomTimeline;
import ru.tagallteam.cataclysm.configuration.timeline.model.TimelineDto;

@FeignClient(name = "timeline-service", url = "${service.timeline-service.url}")
public interface TimelineService {
    @PostMapping("/timeline")
    TimelineDto createTimeline(@RequestBody Long parentTimelineId);

    @PostMapping("/timeline/random")
    TimelineDto createRandomTimeline();

    @GetMapping("/timeline/random")
    RandomTimeline getRandomTimeline();

    @GetMapping("/timeline/{timelineId}")
    TimelineDto getTimeline(@PathVariable Long timelineId);
}
