package ru.tagallteam.cataclysm.error.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import ru.tagallteam.cataclysm.error.model.ApplicationError;

@Getter
@AllArgsConstructor(staticName = "of")
public class ApplicationException extends RuntimeException {
    private ApplicationError error;
}
