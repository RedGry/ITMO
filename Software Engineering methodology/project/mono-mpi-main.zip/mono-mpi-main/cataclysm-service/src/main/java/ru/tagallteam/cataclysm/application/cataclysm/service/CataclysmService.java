package ru.tagallteam.cataclysm.application.cataclysm.service;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import ru.tagallteam.cataclysm.application.cataclysm.domain.Cataclysm;
import ru.tagallteam.cataclysm.application.cataclysm.domain.CataclysmRepository;
import ru.tagallteam.cataclysm.application.cataclysm.domain.CataclysmType;
import ru.tagallteam.cataclysm.application.cataclysm.domain.CataclysmTypeRepository;
import ru.tagallteam.cataclysm.application.cataclysm.mapper.CataclysmMapper;
import ru.tagallteam.cataclysm.application.cataclysm.model.CataclysmCreateDto;
import ru.tagallteam.cataclysm.application.cataclysm.model.CataclysmDto;
import ru.tagallteam.cataclysm.error.ErrorDescriptor;

import java.util.List;

@Service
@AllArgsConstructor
public class CataclysmService {

    private final CataclysmMapper cataclysmMapper;

    private final CataclysmTypeRepository cataclysmTypeRepository;

    private final CataclysmRepository cataclysmRepository;

    @Transactional
    public CataclysmDto createCataclysm(CataclysmCreateDto cataclysmCreateDto) {
        CataclysmType type = null;
        if (cataclysmCreateDto.getTypeId() != null) {
            type = cataclysmTypeRepository.getReferenceById(cataclysmCreateDto.getTypeId());
        }
        return cataclysmMapper.convertToCataclysmDto(
                cataclysmRepository.save(cataclysmMapper.convertToCataclysm(cataclysmCreateDto, type))
        );
    }

    public List<CataclysmDto> getCataclysms(Long page, Long limit) {
        Pageable pageable = PageRequest.of(
                ObjectUtils.isEmpty(page) ? 0 : page.intValue(),
                ObjectUtils.isEmpty(limit) ? 10 : limit.intValue()
        );
        return cataclysmRepository.findAll(pageable).map(cataclysmMapper::convertToCataclysmDto)
                .stream().filter(cataclysmDto -> !ObjectUtils.isEmpty(cataclysmDto.getTimeline()))
                .toList();
    }

    @Transactional
    public CataclysmDto getCataclysm(Long cataclysmId) {
        ErrorDescriptor.CATACLYSM_NOT_FOUND.throwIsFalse(cataclysmRepository.existsById(cataclysmId));
        return cataclysmMapper.convertToCataclysmDto(cataclysmRepository.getReferenceById(cataclysmId));
    }


    @Transactional
    public CataclysmDto updateCataclysm(Long cataclysmId, CataclysmCreateDto cataclysmCreateDto
    ) {
        ErrorDescriptor.CATACLYSM_NOT_FOUND.throwIsFalse(cataclysmRepository.existsById(cataclysmId));
        ErrorDescriptor.CATACLYSM_TYPE_NOT_FOUND.throwIsFalse(
                !ObjectUtils.isEmpty(cataclysmCreateDto.getTypeId()) &&
                        cataclysmTypeRepository.existsById(cataclysmCreateDto.getTypeId())
        );
        CataclysmType type = cataclysmTypeRepository.getReferenceById(cataclysmCreateDto.getTypeId());
        Cataclysm cataclysm = cataclysmRepository.getReferenceById(cataclysmId);
        return cataclysmMapper.convertToCataclysmDto(
                cataclysmRepository.save(cataclysmMapper.convertToCataclysm(cataclysm, cataclysmCreateDto, type))
        );
    }


    public void deleteCataclysm(Long cataclysmId) {
        ErrorDescriptor.CATACLYSM_NOT_FOUND.throwIsFalse(cataclysmRepository.existsById(cataclysmId));
        cataclysmRepository.deleteById(cataclysmId);
    }
}
