package ru.tagallteam.cataclysm.application.cataclysm.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CataclysmRepository extends JpaRepository<Cataclysm, Long> {
}
