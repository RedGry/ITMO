package ru.tagallteam.cataclysm.application.cataclysm.domain;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@Entity
@ToString(of = "id")
@Table(name = "type")
public class CataclysmType {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence")
    @SequenceGenerator(name = "sequence", allocationSize = 1, sequenceName = "type_seq")
    private Long id;
    private String name;
    @OneToMany(mappedBy = "cataclysmType", cascade = CascadeType.ALL)
    private List<Cataclysm> cataclysms;
}
