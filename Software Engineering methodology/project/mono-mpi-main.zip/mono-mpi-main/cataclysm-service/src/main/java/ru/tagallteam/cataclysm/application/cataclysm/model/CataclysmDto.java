package ru.tagallteam.cataclysm.application.cataclysm.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import ru.tagallteam.cataclysm.application.common.Constants;
import ru.tagallteam.cataclysm.configuration.timeline.model.TimelineDto;

import java.time.LocalTime;

@Data
public class CataclysmDto {
    private Long id;
    private TimelineDto timeline;
    private String place;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern = Constants.TIME_FORMAT)
    private LocalTime time;
    private String description;
    private CataclysmTypeDto type;
}
