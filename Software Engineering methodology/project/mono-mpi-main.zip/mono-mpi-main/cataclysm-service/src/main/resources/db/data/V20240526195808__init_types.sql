insert into type(id, name)
values (nextval('type_seq'), 'Слабый'),
       (nextval('type_seq'), 'Средний'),
       (nextval('type_seq'), 'Уничтожение');