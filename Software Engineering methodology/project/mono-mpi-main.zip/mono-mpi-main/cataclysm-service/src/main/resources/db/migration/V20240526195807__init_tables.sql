create sequence type_seq;

create table type
(
    id   int primary key,
    name varchar(256)
);

create sequence cataclysm_seq;

create table cataclysm
(
    id          int primary key,
    type_id     int references type (id),
    timeline_id int           not null,
    place       varchar(1024) not null,
    time        time          not null,
    description text
);
