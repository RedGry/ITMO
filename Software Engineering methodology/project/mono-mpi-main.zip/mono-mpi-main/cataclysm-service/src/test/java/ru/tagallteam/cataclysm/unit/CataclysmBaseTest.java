package ru.tagallteam.cataclysm.unit;

import ru.tagallteam.cataclysm.application.cataclysm.domain.Cataclysm;
import ru.tagallteam.cataclysm.application.cataclysm.domain.CataclysmType;
import ru.tagallteam.cataclysm.application.cataclysm.model.CataclysmCreateDto;
import ru.tagallteam.cataclysm.application.cataclysm.model.CataclysmDto;
import ru.tagallteam.cataclysm.application.cataclysm.model.CataclysmTypeDto;
import ru.tagallteam.cataclysm.configuration.timeline.model.RandomTimeline;
import ru.tagallteam.cataclysm.configuration.timeline.model.TimelineDto;

import java.time.LocalTime;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

public abstract class CataclysmBaseTest {

    protected final Long TIMELINE_ID = 1L;
    protected final Long EXCEPTION_CATACLYSM_ID = 10L;
    protected final Long CATACLYSM_ID = 1L;
    protected final CataclysmCreateDto CREATE_DTO = cataclysmCreateDto();
    protected final CataclysmCreateDto CREATE_WITHOUT_TYPE_DTO = cataclysmCreateWithOutTypeDto();
    protected final CataclysmType CATACLYSM_TYPE = cataclysmType();
    protected final CataclysmTypeDto CATACLYSM_TYPE_DTO = cataclysmTypeDto();
    protected final Cataclysm CATACLYSM = cataclysm();
    protected final Cataclysm CATACLYSM_WITHOUT_TYPE = cataclysmWithoutType();
    protected final CataclysmDto CATACLYSM_DTO = cataclysmDto(true);
    protected final CataclysmDto CATACLYSM_WITHOUT_TYPE_DTO = cataclysmDto(false);
    protected final RandomTimeline randomTimeline = randomTimeline();
    protected final TimelineDto timelineDto = timelineDto();

    protected void resultValid(CataclysmDto result, boolean withType) {
        assertNotNull(result);
        assertEquals(result.getPlace(), CREATE_DTO.getPlace());
        if (withType) {
            assertEquals(result.getType().getId(), CREATE_DTO.getTypeId());
        } else {
            assertNull(result.getType());
        }
        assertEquals(result.getDescription(), CREATE_DTO.getDescription());
    }

    private CataclysmCreateDto cataclysmCreateDto() {
        CataclysmCreateDto dto = new CataclysmCreateDto();
        dto.setPlace("TestPlace");
        dto.setTypeId(1L);
        dto.setDescription("Test");
        dto.setTime(LocalTime.now());
        return dto;
    }

    private CataclysmCreateDto cataclysmCreateWithOutTypeDto() {
        CataclysmCreateDto dto = new CataclysmCreateDto();
        dto.setPlace("TestPlace");
        dto.setDescription("Test");
        dto.setTime(LocalTime.now());
        return dto;
    }

    private CataclysmType cataclysmType() {
        CataclysmType type = new CataclysmType();
        type.setId(1L);
        type.setName("TestType");
        return type;
    }

    private CataclysmTypeDto cataclysmTypeDto() {
        CataclysmTypeDto type = new CataclysmTypeDto();
        type.setId(1L);
        type.setName("TestType");
        return type;
    }

    private Cataclysm cataclysm() {
        Cataclysm cataclysm = new Cataclysm();
        cataclysm.setId(CATACLYSM_ID);
        cataclysm.setCataclysmType(CATACLYSM_TYPE);
        cataclysm.setTimelineId(TIMELINE_ID);
        cataclysm.setPlace(CREATE_DTO.getPlace());
        cataclysm.setTime(CREATE_DTO.getTime());
        cataclysm.setDescription(CREATE_DTO.getDescription());
        return cataclysm;
    }

    private Cataclysm cataclysmWithoutType() {
        Cataclysm cataclysm = new Cataclysm();
        cataclysm.setId(CATACLYSM_ID);
        cataclysm.setTimelineId(TIMELINE_ID);
        cataclysm.setPlace(CREATE_DTO.getPlace());
        cataclysm.setTime(CREATE_DTO.getTime());
        cataclysm.setDescription(CREATE_DTO.getDescription());
        return cataclysm;
    }

    private CataclysmDto cataclysmDto(boolean withType) {
        CataclysmDto cataclysm = new CataclysmDto();
        cataclysm.setId(CATACLYSM_ID);
        cataclysm.setTimeline(timelineDto());
        cataclysm.setPlace(CREATE_DTO.getPlace());
        cataclysm.setTime(CREATE_DTO.getTime());
        cataclysm.setDescription(CREATE_DTO.getDescription());
        if (withType) {
            cataclysm.setType(CATACLYSM_TYPE_DTO);
        }
        return cataclysm;
    }

    private RandomTimeline randomTimeline() {
        RandomTimeline timeline = new RandomTimeline();
        timeline.setId(TIMELINE_ID);
        return timeline;
    }

    private TimelineDto timelineDto() {
        TimelineDto timeline = new TimelineDto();
        timeline.setId(TIMELINE_ID);
        return timeline;
    }

}
