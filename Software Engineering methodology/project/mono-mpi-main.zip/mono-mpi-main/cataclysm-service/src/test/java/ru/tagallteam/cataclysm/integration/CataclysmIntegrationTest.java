package ru.tagallteam.cataclysm.integration;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.ActiveProfiles;
import ru.tagallteam.cataclysm.application.cataclysm.domain.Cataclysm;
import ru.tagallteam.cataclysm.application.cataclysm.domain.CataclysmRepository;
import ru.tagallteam.cataclysm.application.cataclysm.model.CataclysmDto;
import ru.tagallteam.cataclysm.application.cataclysm.service.CataclysmService;
import ru.tagallteam.cataclysm.configuration.timeline.service.TimelineService;
import ru.tagallteam.cataclysm.error.exception.ApplicationException;
import ru.tagallteam.cataclysm.unit.CataclysmBaseTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

@SpringBootTest
@ActiveProfiles("test")
public class CataclysmIntegrationTest extends CataclysmBaseTest {

    @MockBean
    private TimelineService timelineService;

    @Autowired
    private CataclysmService cataclysmService;

    @Autowired
    private CataclysmRepository cataclysmRepository;

    @BeforeEach
    public void setUp() {
        when(timelineService.createRandomTimeline()).thenReturn(timelineDto);
        cataclysmRepository.deleteById(CATACLYSM_ID);
    }

    @Test
    public void createCataclysmWithTypeTest() {
        resultValid(cataclysmService.createCataclysm(CREATE_DTO), true);
        cataclysmRepository.deleteById(CATACLYSM_ID);
    }

    @Test
    public void createCataclysmWithoutTypeTest() {
        resultValid(cataclysmService.createCataclysm(CREATE_WITHOUT_TYPE_DTO), false);
    }

    @Test
    public void getCataclysmTest() {
        Cataclysm cataclysm = cataclysmRepository.save(CATACLYSM);
        resultValid(cataclysmService.getCataclysm(cataclysm.getId()), true);
    }

    @Test
    public void getCataclysmWithException() {
        assertThrows(ApplicationException.class, () -> cataclysmService.getCataclysm(CATACLYSM_ID));
    }

    @Test
    public void deleteCataclysmWithException() {
        assertThrows(ApplicationException.class, () -> cataclysmService.deleteCataclysm(CATACLYSM_ID));
    }

    @Test
    public void deleteCataclysm() {
        cataclysmRepository.save(CATACLYSM);
        cataclysmService.deleteCataclysm(CATACLYSM_ID);
        assertThrows(ApplicationException.class, () -> cataclysmService.getCataclysm(CATACLYSM_ID));
    }

    @Test
    public void updateCataclysm() {
        Cataclysm cataclysm = cataclysmRepository.save(CATACLYSM);
        CREATE_DTO.setPlace("New place Test");
        CataclysmDto result = cataclysmService.updateCataclysm(cataclysm.getId(), CREATE_DTO);
        assertEquals(CREATE_DTO.getPlace(), result.getPlace());
    }

    @Test
    public void updateCataclysmExceptionNotFound() {
        assertThrows(ApplicationException.class, () ->
                cataclysmService.updateCataclysm(EXCEPTION_CATACLYSM_ID, CREATE_DTO));
    }

    @Test
    public void updateCataclysmExceptionTypeNotFound() {
        Cataclysm cataclysm = cataclysmRepository.save(CATACLYSM);
        assertThrows(ApplicationException.class, () ->
                cataclysmService.updateCataclysm(cataclysm.getId(), CREATE_WITHOUT_TYPE_DTO));
    }

}
