package ru.tagallteam.cataclysm.unit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import ru.tagallteam.cataclysm.application.cataclysm.domain.Cataclysm;
import ru.tagallteam.cataclysm.application.cataclysm.mapper.CataclysmMapper;
import ru.tagallteam.cataclysm.configuration.timeline.service.TimelineService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class CataclysmMapperTest extends CataclysmBaseTest {

    @InjectMocks
    private CataclysmMapper cataclysmMapper;

    @Mock
    private TimelineService timelineService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        when(timelineService.createRandomTimeline()).thenReturn(timelineDto);
        when(timelineService.getTimeline(Mockito.any())).thenReturn(timelineDto);
    }

    @Test
    public void convertToCataclysmTest() {
        validateMappingToBoseModel(cataclysmMapper.convertToCataclysm(CREATE_DTO, CATACLYSM_TYPE));
    }

    @Test
    public void convertToCataclysmForUpdateTest() {
        validateMappingToBoseModel(cataclysmMapper.convertToCataclysm(CATACLYSM, CREATE_DTO, CATACLYSM_TYPE));
    }

    @Test
    public void convertToCataclysmDtoTest() {
        assertEquals(CATACLYSM_DTO, cataclysmMapper.convertToCataclysmDto(CATACLYSM));
    }


    @Test
    public void convertToCataclysmTypeDtoTest() {
        assertEquals(CATACLYSM_TYPE_DTO, cataclysmMapper.convertToCataclysmTypeDto(CATACLYSM_TYPE));
    }

    private void validateMappingToBoseModel(Cataclysm cataclysm) {
        assertEquals(CATACLYSM.getTimelineId(), cataclysm.getTimelineId());
        assertEquals(CATACLYSM.getCataclysmType(), cataclysm.getCataclysmType());
        assertEquals(CATACLYSM.getPlace(), cataclysm.getPlace());
        assertEquals(CATACLYSM.getDescription(), cataclysm.getDescription());
        assertEquals(CATACLYSM.getTime(), cataclysm.getTime());
    }
}
