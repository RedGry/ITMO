package ru.tagallteam.cataclysm.unit;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import ru.tagallteam.cataclysm.application.cataclysm.domain.CataclysmRepository;
import ru.tagallteam.cataclysm.application.cataclysm.domain.CataclysmTypeRepository;
import ru.tagallteam.cataclysm.application.cataclysm.mapper.CataclysmMapper;
import ru.tagallteam.cataclysm.application.cataclysm.model.CataclysmDto;
import ru.tagallteam.cataclysm.application.cataclysm.service.CataclysmService;
import ru.tagallteam.cataclysm.error.exception.ApplicationException;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

class CataclysmServiceTest extends CataclysmBaseTest {

    @InjectMocks
    private CataclysmService cataclysmService;

    @Mock
    private CataclysmMapper cataclysmMapper;

    @Mock
    protected CataclysmTypeRepository cataclysmTypeRepository;

    @Mock
    protected CataclysmRepository cataclysmRepository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        when(cataclysmTypeRepository.getReferenceById(CATACLYSM.getCataclysmType().getId())).thenReturn(CATACLYSM_TYPE);
        when(cataclysmTypeRepository.existsById(Mockito.any())).thenReturn(true);
        when(cataclysmTypeRepository.existsById(CATACLYSM.getCataclysmType().getId())).thenReturn(true);
        when(cataclysmRepository.getReferenceById(CATACLYSM.getId())).thenReturn(CATACLYSM);
        when(cataclysmRepository.save(CATACLYSM)).thenReturn(CATACLYSM);
        when(cataclysmRepository.save(CATACLYSM_WITHOUT_TYPE)).thenReturn(CATACLYSM_WITHOUT_TYPE);
        when(cataclysmRepository.existsById(Mockito.any())).thenReturn(false);
        when(cataclysmRepository.existsById(CATACLYSM.getId())).thenReturn(true);

        when(cataclysmMapper.convertToCataclysm(CREATE_DTO, CATACLYSM_TYPE)).thenReturn(CATACLYSM);
        when(cataclysmMapper.convertToCataclysm(CREATE_WITHOUT_TYPE_DTO, null)).thenReturn(CATACLYSM_WITHOUT_TYPE);
        when(cataclysmMapper.convertToCataclysm(CATACLYSM, CREATE_DTO, CATACLYSM_TYPE)).thenReturn(CATACLYSM);
        when(cataclysmMapper.convertToCataclysmDto(CATACLYSM)).thenReturn(CATACLYSM_DTO);
        when(cataclysmMapper.convertToCataclysmDto(CATACLYSM_WITHOUT_TYPE)).thenReturn(CATACLYSM_WITHOUT_TYPE_DTO);
        when(cataclysmMapper.convertToCataclysmTypeDto(CATACLYSM_TYPE)).thenReturn(CATACLYSM_TYPE_DTO);
    }

    @Test
    void createCataclysmWithType() {
        CataclysmDto result = cataclysmService.createCataclysm(CREATE_DTO);
        resultValid(result, true);
    }

    @Test
    void createCataclysmWithOutType() {
        CataclysmDto result = cataclysmService.createCataclysm(CREATE_WITHOUT_TYPE_DTO);
        resultValid(result, false);
    }

    @Test
    void getCataclysmNotFound() {
        assertThrows(ApplicationException.class, () -> cataclysmService.getCataclysm(EXCEPTION_CATACLYSM_ID));
    }

    @Test
    void getCataclysmFound() {
        CataclysmDto result = cataclysmService.getCataclysm(CATACLYSM_ID);
        resultValid(result, true);
    }

    @Test
    void updateCataclysmErrorNotFound() {
        assertThrows(
                ApplicationException.class,
                () -> cataclysmService.updateCataclysm(EXCEPTION_CATACLYSM_ID, CREATE_DTO)
        );
    }

    @Test
    void updateCataclysmErrorNotFoundType() {
        assertThrows(
                ApplicationException.class,
                () -> cataclysmService.updateCataclysm(EXCEPTION_CATACLYSM_ID, CREATE_WITHOUT_TYPE_DTO)
        );
    }

    @Test
    void updateCataclysm() {
        CataclysmDto result = cataclysmService.updateCataclysm(CATACLYSM_ID, CREATE_DTO);
        resultValid(result, true);
    }
}

