create sequence token_seq;

create table token
(
    id      int primary key,
    user_id int  not null,
    token   text not null
);
