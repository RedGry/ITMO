package ru.tagallteam.auth.application.auth.service;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.tagallteam.auth.application.auth.domain.Token;
import ru.tagallteam.auth.application.auth.domain.TokenRepository;
import ru.tagallteam.auth.application.auth.model.AuthDto;
import ru.tagallteam.auth.application.auth.model.Status;

@Service
@RequiredArgsConstructor
public class AuthService {
    private final TokenRepository tokenRepository;

    public AuthDto login(AuthDto authDto, Long userId) {
        if (!tokenRepository.existsByToken(authDto.getToken())) {
            Token token = new Token();
            token.setToken(authDto.getToken());
            token.setUserId(userId);
            token = tokenRepository.save(token);
            AuthDto saveAuthDto = new AuthDto();
            saveAuthDto.setToken(token.getToken());
            return saveAuthDto;
        }
        return authDto;
    }

    @Transactional
    public void logout(AuthDto authDto) {
        if (tokenRepository.existsByToken(authDto.getToken())) {
            tokenRepository.deleteByToken(authDto.getToken());
        }
    }

    public Status isLogin(AuthDto authDto) {
        Status status = new Status();
        status.setLogin(tokenRepository.existsByToken(authDto.getToken()));
        return status;
    }
}
