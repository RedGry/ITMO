package ru.tagallteam.auth.application.auth.model;

import lombok.Data;

@Data
public class Status {
    boolean login;
}
