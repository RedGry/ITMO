package ru.tagallteam.auth.error.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import ru.tagallteam.auth.error.model.ApplicationError;

@Getter
@AllArgsConstructor(staticName = "of")
public class ApplicationException extends RuntimeException {
    private ApplicationError error;
}
