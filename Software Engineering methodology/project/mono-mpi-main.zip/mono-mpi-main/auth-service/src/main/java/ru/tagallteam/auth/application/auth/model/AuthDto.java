package ru.tagallteam.auth.application.auth.model;

import lombok.Data;

@Data
public class AuthDto {
    String token;
}
