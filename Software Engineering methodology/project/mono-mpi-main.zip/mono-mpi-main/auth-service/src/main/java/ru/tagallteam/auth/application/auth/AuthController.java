package ru.tagallteam.auth.application.auth;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.tagallteam.auth.application.auth.model.AuthDto;
import ru.tagallteam.auth.application.auth.model.Status;
import ru.tagallteam.auth.application.auth.service.AuthService;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/auth")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/login/{userId}")
    public AuthDto login(@RequestBody AuthDto authDto, @PathVariable Long userId) {
        return authService.login(authDto, userId);
    }

    @DeleteMapping("/logout")
    public void logout(@RequestBody AuthDto authDto) {
        authService.logout(authDto);
    }

    @PostMapping("/is-login")
    public Status isLogin(@RequestBody AuthDto authDto) {
        return authService.isLogin(authDto);
    }
}
