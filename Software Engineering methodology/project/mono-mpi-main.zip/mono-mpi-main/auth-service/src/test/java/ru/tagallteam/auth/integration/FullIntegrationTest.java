package ru.tagallteam.auth.integration;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import ru.tagallteam.auth.application.auth.domain.TokenRepository;
import ru.tagallteam.auth.application.auth.model.AuthDto;
import ru.tagallteam.auth.application.auth.model.Status;
import ru.tagallteam.auth.application.auth.service.AuthService;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@ActiveProfiles("test")
public class FullIntegrationTest {
    @Autowired
    private AuthService authService;

    @Autowired
    private TokenRepository tokenRepository;

    @Test
    void testFullAuthorizationProcess() {
        AuthDto authDto = new AuthDto();
        authDto.setToken("testToken");
        Status statusBeforeLogin = authService.isLogin(authDto);
        assertNotNull(statusBeforeLogin);
        assertFalse(statusBeforeLogin.isLogin(), "Статус должен быть false, так как пользователь не авторизован");
        authService.login(authDto, 1L);
        Status statusAfterLogin = authService.isLogin(authDto);
        assertNotNull(statusAfterLogin);
        assertTrue(statusAfterLogin.isLogin(), "Статус должен быть true после успешной авторизации");
        authService.logout(authDto);
        Status statusAfterLogout = authService.isLogin(authDto);
        assertNotNull(statusAfterLogout);
        assertFalse(statusAfterLogout.isLogin(), "Статус должен быть false после выхода из системы");
    }
}
