package ru.tagallteam.auth.integration;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import ru.tagallteam.auth.application.auth.domain.TokenRepository;
import ru.tagallteam.auth.application.auth.model.AuthDto;
import ru.tagallteam.auth.application.auth.service.AuthService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@ActiveProfiles("test")
class LoginAndLogoutTest {

    @Autowired
    private AuthService authService;

    @Autowired
    private TokenRepository tokenRepository;

    @Test
    void testLogin_NewToken() {
        AuthDto authDto = new AuthDto();
        authDto.setToken("newToken");
        AuthDto result = authService.login(authDto, 1L);
        assertNotNull(result);
        assertEquals("newToken", result.getToken());
        assertTrue(tokenRepository.existsByToken("newToken"));
    }

    @Test
    void testLogout_ExistingToken() {
        AuthDto authDto = new AuthDto();
        authDto.setToken("existingToken");
        authService.login(authDto, 1L);
        assertTrue(tokenRepository.existsByToken("existingToken"));
        authService.logout(authDto);
        assertFalse(tokenRepository.existsByToken("existingToken"));
    }
}

