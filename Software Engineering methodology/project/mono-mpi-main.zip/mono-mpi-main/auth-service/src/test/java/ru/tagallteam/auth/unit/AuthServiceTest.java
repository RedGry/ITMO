package ru.tagallteam.auth.unit;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import ru.tagallteam.auth.application.auth.domain.Token;
import ru.tagallteam.auth.application.auth.domain.TokenRepository;
import ru.tagallteam.auth.application.auth.model.AuthDto;
import ru.tagallteam.auth.application.auth.model.Status;
import ru.tagallteam.auth.application.auth.service.AuthService;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;


class AuthServiceTest {

    @Mock
    private TokenRepository tokenRepository;

    @InjectMocks
    private AuthService authService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testLogin_NewToken() {
        AuthDto authDto = new AuthDto();
        authDto.setToken("testToken");
        Long userId = 1L;
        when(tokenRepository.existsByToken("testToken")).thenReturn(false);
        when(tokenRepository.save(any(Token.class))).thenAnswer(invocation -> {
            Token token = invocation.getArgument(0);
            token.setId(1L);  // присваиваем ID для имитации сохранения
            return token;
        });
        AuthDto result = authService.login(authDto, userId);
        assertNotNull(result);
        assertEquals("testToken", result.getToken());
        verify(tokenRepository, times(1)).existsByToken("testToken");
        verify(tokenRepository, times(1)).save(any(Token.class));
    }

    @Test
    void testLogin_ExistingToken() {
        AuthDto authDto = new AuthDto();
        authDto.setToken("testToken");
        Long userId = 1L;
        when(tokenRepository.existsByToken("testToken")).thenReturn(true);
        AuthDto result = authService.login(authDto, userId);
        assertNotNull(result);
        assertEquals("testToken", result.getToken());
        verify(tokenRepository, times(1)).existsByToken("testToken");
        verify(tokenRepository, times(0)).save(any(Token.class));  // проверка, что save не вызывается
    }

    @Test
    void testLogout_ExistingToken() {
        AuthDto authDto = new AuthDto();
        authDto.setToken("testToken");
        when(tokenRepository.existsByToken("testToken")).thenReturn(true);
        authService.logout(authDto);
        verify(tokenRepository, times(1)).existsByToken("testToken");
        verify(tokenRepository, times(1)).deleteByToken("testToken");
    }

    @Test
    void testLogout_NonExistingToken() {
        AuthDto authDto = new AuthDto();
        authDto.setToken("testToken");
        when(tokenRepository.existsByToken("testToken")).thenReturn(false);
        authService.logout(authDto);
        verify(tokenRepository, times(1)).existsByToken("testToken");
        verify(tokenRepository, times(0)).deleteByToken(anyString());  // проверка, что delete не вызывается
    }

    @Test
    void testIsLogin_ExistingToken() {
        AuthDto authDto = new AuthDto();
        authDto.setToken("testToken");
        when(tokenRepository.existsByToken("testToken")).thenReturn(true);
        Status status = authService.isLogin(authDto);
        assertNotNull(status);
        assertTrue(status.isLogin());
        verify(tokenRepository, times(1)).existsByToken("testToken");
    }

    @Test
    void testIsLogin_NonExistingToken() {
        AuthDto authDto = new AuthDto();
        authDto.setToken("testToken");
        when(tokenRepository.existsByToken("testToken")).thenReturn(false);
        Status status = authService.isLogin(authDto);
        assertNotNull(status);
        assertFalse(status.isLogin());
        verify(tokenRepository, times(1)).existsByToken("testToken");
    }
}

