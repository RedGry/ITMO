rootProject.name = "auth-service"
