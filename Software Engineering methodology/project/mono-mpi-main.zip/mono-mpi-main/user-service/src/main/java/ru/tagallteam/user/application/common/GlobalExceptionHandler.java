package ru.tagallteam.user.application.common;

import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.NoHandlerFoundException;
import ru.tagallteam.user.error.ErrorDescriptor;
import ru.tagallteam.user.error.exception.ApplicationException;
import ru.tagallteam.user.error.model.ApplicationError;

/**
 * Обработка ошибок приложения.
 *
 * @author Iurii Babalin.
 */
@Slf4j
@ControllerAdvice
@RequiredArgsConstructor
public class GlobalExceptionHandler {

    /**
     * Обработка исключения {@link NoHandlerFoundException}.
     *
     * @param ex исключение.
     * @return ошибка приложения.
     */
    @ResponseBody
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(NoHandlerFoundException.class)
    public ApplicationError handleError404(NoHandlerFoundException ex) {
        log.error("NoHandlerFoundException exception: {}", ex.getMessage());
        return ErrorDescriptor.NOT_FOUND.applicationError();
    }


    /**
     * Обработка исключения {@link ApplicationException}.
     *
     * @param ex исключение.
     * @return ошибка приложения.
     */
    @ResponseBody
    @ExceptionHandler(ApplicationException.class)
    public ApplicationError applicationException(ApplicationException ex, HttpServletResponse response) {
        log.error("ApplicationException exception: {}", ex.getError().getError());
        response.setHeader(HttpHeaders.CONTENT_TYPE, "application/json; charset=UTF-8");
        response.setStatus(ex.getError().getStatus().value());
        return ex.getError();
    }

    /**
     * Обработка исключения {@link Exception}.
     *
     * @param ex исключение.
     * @return ошибка приложения.
     */
    @ResponseBody
    @ExceptionHandler(IllegalArgumentException.class)
    public ApplicationError exception(IllegalArgumentException ex, HttpServletResponse response) {
        log.error("IllegalArgumentException exception: {}", ex.getMessage());
        response.setStatus(ErrorDescriptor.DATA_BASE_ERROR.getStatus().value());
        ApplicationError error = ErrorDescriptor.DATA_BASE_ERROR.applicationError();
        error.setError(ex.getMessage());
        return error;
    }

}
