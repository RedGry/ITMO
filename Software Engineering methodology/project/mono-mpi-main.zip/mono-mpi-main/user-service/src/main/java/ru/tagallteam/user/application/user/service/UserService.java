package ru.tagallteam.user.application.user.service;

import lombok.AllArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import ru.tagallteam.user.application.user.domain.User;
import ru.tagallteam.user.application.user.domain.UserRepository;
import ru.tagallteam.user.application.user.mapper.UserMapper;
import ru.tagallteam.user.application.user.model.PasswordDto;
import ru.tagallteam.user.application.user.model.UserCreateDto;
import ru.tagallteam.user.application.user.model.UserDto;
import ru.tagallteam.user.error.ErrorDescriptor;
import ru.tagallteam.user.utils.PasswordHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Service
@AllArgsConstructor
public class UserService {

    private final UserRepository userRepository;

    private final PasswordEncoder passwordEncoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();

    private final UserMapper userMapper;

    public UserDto create(UserCreateDto userCreateDto) {
        ErrorDescriptor.LOGIN_USED.throwIsTrue(userRepository.existsByLogin(userCreateDto.getLogin()));
        return userMapper.toUserDto(userRepository.save(userMapper.toUser(userCreateDto)));
    }

    public UserDto getUser(Long userId) {
        ErrorDescriptor.USER_NOT_FOUND.throwIsFalse(userRepository.existsById(userId));
        return userMapper.toUserDto(userRepository.getReferenceById(userId));
    }

    public List<UserDto> getUsers(Long page, Long limit) {
        Pageable pageable = PageRequest.of(
                ObjectUtils.isEmpty(page) ? 0 : page.intValue(),
                ObjectUtils.isEmpty(limit) ? 10 : limit.intValue()
        );
        return userRepository.findAll(pageable).map(userMapper::toUserDto).toList();
    }


    public UserDto updateUser(Long userId, UserCreateDto userCreateDto) {
        ErrorDescriptor.USER_NOT_FOUND.throwIsFalse(userRepository.existsById(userId));
        ErrorDescriptor.PASSWORD_NOT_EMPTY.throwIsTrue(ObjectUtils.isEmpty(userCreateDto.getPassword()));
        if (!userRepository.getReferenceById(userId).getLogin().equals(userCreateDto.getLogin())) {
            ErrorDescriptor.LOGIN_USED.throwIsTrue(userRepository.existsByLogin(userCreateDto.getLogin()));
        }
        User user = userMapper.toUser(userCreateDto);
        user.setId(userId);
        return userMapper.toUserDto(userRepository.save(user));
    }

    public PasswordDto generatePassword(Long userId) {
        ErrorDescriptor.USER_NOT_FOUND.throwIsFalse(userRepository.existsById(userId));
        User user = userRepository.getReferenceById(userId);
        String password = PasswordHelper.generatePassword(randInt(7, 10));
        System.out.println(password);
        user.setPassword(passwordEncoder.encode(password));
        userRepository.save(user);
        PasswordDto passwordDto = new PasswordDto();
        passwordDto.setPassword(password);
        return passwordDto;
    }

    public UserDto login(String login) {
        ErrorDescriptor.USER_NOT_FOUND.throwIsFalse(userRepository.existsByLogin(login));
        return userMapper.toUserDto(userRepository.findByLogin(login));
    }

    public PasswordDto loginPass(Long userId) {
        ErrorDescriptor.USER_NOT_FOUND.throwIsFalse(userRepository.existsById(userId));
        User user = userRepository.getReferenceById(userId);
        PasswordDto passwordDto = new PasswordDto();
        passwordDto.setPassword(user.getPassword());
        return passwordDto;
    }

    public List<UserDto> getFreeUsers(List<Long> notFreeIds) {
        if(notFreeIds.isEmpty()){
            return userRepository.findAll().stream()
                    .filter(user -> user.getRole().getId().equals(1L) || user.getRole().getId().equals(4L))
                    .map(userMapper::toUserDto)
                    .toList();
        }
        return userRepository.findAllByIdNotIn(notFreeIds).stream()
                .filter(user -> user.getRole().getId().equals(1L) || user.getRole().getId().equals(4L))
                .map(userMapper::toUserDto).toList();
    }

    private static int randInt(int min, int max) {
        return new Random().nextInt((max - min) + 1) + min;
    }
}
