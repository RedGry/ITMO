package ru.tagallteam.user.error;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.util.ObjectUtils;
import ru.tagallteam.user.error.exception.ApplicationException;
import ru.tagallteam.user.error.model.ApplicationError;

@Getter
@AllArgsConstructor
public enum ErrorDescriptor {

    UNAUTHORIZED_ACCESS("Неавторизованный доступ", HttpStatus.UNAUTHORIZED),
    PASSWORD_NOT_EMPTY("Пароль не может быть пустым", HttpStatus.BAD_REQUEST),
    ACCESS_DENIED("Недостаточно прав для доступа к ресурсу", HttpStatus.FORBIDDEN),
    ROLE_NOT_FOUND("Роль не найдена", HttpStatus.NOT_FOUND),
    USER_NOT_FOUND("Пользователь не найден", HttpStatus.NOT_FOUND),
    LOGIN_USED("Этот login уже занят", HttpStatus.BAD_REQUEST),
    NOT_FOUND_TIMELINE("Такого timeline не существует", HttpStatus.NOT_FOUND),
    DATA_BASE_ERROR("Ошибка взаимодействия с бд", HttpStatus.BAD_REQUEST),
    INTERNAL_SERVER_ERROR("Неожиданная ошибка сервиса", HttpStatus.INTERNAL_SERVER_ERROR),
    NOT_FOUND("Запрошенный ресурс (интерфейс) не существует", HttpStatus.NOT_FOUND);


    private final String message;


    private final HttpStatus status;

    public void exception() {
        throw ApplicationException.of(applicationError());
    }

    public ApplicationException callExceptionModel() {
        return ApplicationException.of(applicationError());
    }

    public void throwIsTrue(Boolean flag) {
        if (flag) {
            exception();
        }
    }

    public void throwIsFalse(Boolean flag) {
        if (!flag) {
            exception();
        }
    }

    public void throwIsNull(Object object) {
        if (ObjectUtils.isEmpty(object)) {
            exception();
        }
    }

    public ApplicationError applicationError() {
        return new ApplicationError(this.message, this.status);
    }

}
