package ru.tagallteam.user.application.user.model;

import lombok.Data;
import ru.tagallteam.user.application.role.model.RoleDto;

@Data
public class UserDto {
    private Long id;
    private String name;
    private String login;
    private RoleDto role;
}
