package ru.tagallteam.user.error.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;
import ru.tagallteam.user.application.common.Constants;

import java.time.LocalDateTime;

/**
 * Ошибка приложения.
 *
 * @author Iurii Babalin.
 */
@Data
@AllArgsConstructor(staticName = "of")
@NoArgsConstructor
public class ApplicationError {

    /**
     * Сообщение об ошибке.
     */
    private String error;

    /**
     * Время ошибки.
     */
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.DATE_TIME_FORMAT)
    private LocalDateTime time;

    /**
     * Стутус, который возвращается при вызове ошибки.
     */
    private HttpStatus status;

    /**
     * Создание ошибки.
     *
     * @param error  текст ошибки.
     * @param status статус ошибки.
     * @return класс ошибки.
     */
    public ApplicationError(String error, HttpStatus status) {
        this.error = error;
        this.status = status;
        this.time = LocalDateTime.now();
    }

    public ApplicationError(String error, HttpStatus status, LocalDateTime time) {
        this.error = error;
        this.status = status;
        this.time = time;
    }
}
