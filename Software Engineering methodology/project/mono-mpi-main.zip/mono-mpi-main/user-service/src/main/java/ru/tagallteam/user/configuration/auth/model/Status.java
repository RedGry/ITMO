package ru.tagallteam.user.configuration.auth.model;

import lombok.Data;

@Data
public class Status {
    boolean login;
}
