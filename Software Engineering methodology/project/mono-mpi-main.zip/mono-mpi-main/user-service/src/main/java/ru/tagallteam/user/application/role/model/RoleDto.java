package ru.tagallteam.user.application.role.model;

import lombok.Data;

@Data
public class RoleDto {
    private Long id;
    private String name;
}
