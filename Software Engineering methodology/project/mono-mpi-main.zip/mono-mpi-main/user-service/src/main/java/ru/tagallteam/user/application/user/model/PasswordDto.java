package ru.tagallteam.user.application.user.model;

import lombok.Data;

@Data
public class PasswordDto {
    String password;
}
