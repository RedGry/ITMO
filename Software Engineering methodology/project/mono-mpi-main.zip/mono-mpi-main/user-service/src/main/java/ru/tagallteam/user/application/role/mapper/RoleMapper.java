package ru.tagallteam.user.application.role.mapper;

import org.springframework.stereotype.Component;
import ru.tagallteam.user.application.role.domain.Role;
import ru.tagallteam.user.application.role.model.RoleDto;

@Component
public class RoleMapper {
    public RoleDto toDto(Role role) {
        RoleDto roleDto = new RoleDto();
        roleDto.setId(role.getId());
        roleDto.setName(role.getName());
        return roleDto;
    }
}
