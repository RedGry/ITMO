package ru.tagallteam.user.configuration;

import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import ru.tagallteam.user.error.ErrorDescriptor;
import ru.tagallteam.user.error.model.ApplicationError;
import ru.tagallteam.user.filter.JwtFilter;
import ru.tagallteam.user.utils.HttpResponseUtils;

import java.time.LocalDateTime;
import java.util.Collections;


@Configuration
@EnableWebSecurity
@RequiredArgsConstructor
public class SecurityConfiguration {

    private final JwtFilter jwtFilter;


    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .exceptionHandling()
                .accessDeniedHandler(accessDeniedHandler())
                .authenticationEntryPoint(authenticationEntryPoint());
        http
                .authorizeRequests(request -> request
                        .requestMatchers(HttpMethod.GET, "/v1/user/login/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/v1/user/**/login/pass").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/v1/user/login/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/v1/user/**/login/pass").permitAll()
                        .requestMatchers(HttpMethod.GET, "/api/v1/user/**").permitAll()
                        .requestMatchers(HttpMethod.GET, "/v1/user/**").permitAll()
                        .requestMatchers(HttpMethod.PUT,"/v1/**").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.PUT,"/api/v1/**").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.POST,"/v1/**").hasRole("ADMIN")
                        .requestMatchers(HttpMethod.POST,"/api/v1/**").hasRole("ADMIN")
                        .requestMatchers("/v1/**").authenticated()
                        .requestMatchers("/api/v1/**").authenticated()
                        .anyRequest().authenticated()
                );
        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        http.csrf().disable();
        http.cors().configurationSource(corsConfigurationSource());
        http.headers().frameOptions().sameOrigin();
        http.headers().frameOptions().sameOrigin();
        http.addFilterBefore(jwtFilter, UsernamePasswordAuthenticationFilter.class);
        return http.build();
    }

    /**
     * Конфигарация CORS.
     */
    private CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOriginPatterns(Collections.singletonList("*"));
        configuration.setAllowCredentials(true);
        configuration.setAllowedMethods(Collections.singletonList("*"));
        configuration.setAllowedHeaders(Collections.singletonList("*"));
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.setAlwaysUseFullPath(true);
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }

    /**
     * {@see AccessDeniedHandler}.
     */
    private AccessDeniedHandler accessDeniedHandler() {
        ErrorDescriptor errorDescription = ErrorDescriptor.ACCESS_DENIED;
        ApplicationError error = ApplicationError.of(errorDescription.getMessage(), LocalDateTime.now(), errorDescription.getStatus());
        return (request, response, ex) -> HttpResponseUtils.writeError(response, error,
                HttpServletResponse.SC_FORBIDDEN);
    }

    /**
     * {@see AuthenticationEntryPoint}.
     */
    private AuthenticationEntryPoint authenticationEntryPoint() {
        ErrorDescriptor errorDescription = ErrorDescriptor.UNAUTHORIZED_ACCESS;
        ApplicationError error = ApplicationError.of(errorDescription.getMessage(), LocalDateTime.now(), errorDescription.getStatus());
        return (request, response, ex) -> HttpResponseUtils.writeError(response, error,
                HttpServletResponse.SC_UNAUTHORIZED);
    }
}

