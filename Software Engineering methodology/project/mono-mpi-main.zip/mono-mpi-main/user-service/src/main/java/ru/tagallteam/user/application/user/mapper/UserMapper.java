package ru.tagallteam.user.application.user.mapper;

import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import ru.tagallteam.user.application.role.mapper.RoleMapper;
import ru.tagallteam.user.application.role.service.RoleService;
import ru.tagallteam.user.application.user.domain.User;
import ru.tagallteam.user.application.user.model.UserCreateDto;
import ru.tagallteam.user.application.user.model.UserDto;

@Component
@RequiredArgsConstructor
public class UserMapper {

    private final RoleMapper roleMapper;

    private final RoleService roleService;

    private final PasswordEncoder passwordEncoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();

    public UserDto toUserDto(User user) {
        UserDto userDto = new UserDto();
        userDto.setId(user.getId());
        userDto.setLogin(user.getLogin());
        userDto.setName(user.getName());
        userDto.setRole(roleMapper.toDto(user.getRole()));
        return userDto;
    }

    public User toUser(UserCreateDto userDto) {
        User user = new User();
        user.setLogin(userDto.getLogin());
        user.setName(userDto.getName());
        user.setRole(roleService.getRole(userDto.getRoleId()));
        if(userDto.getPassword() != null) {
            user.setPassword(passwordEncoder.encode(userDto.getPassword()));
        }
        return user;
    }
}
