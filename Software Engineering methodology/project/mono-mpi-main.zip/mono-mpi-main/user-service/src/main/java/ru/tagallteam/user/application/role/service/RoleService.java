package ru.tagallteam.user.application.role.service;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import ru.tagallteam.user.application.role.domain.Role;
import ru.tagallteam.user.application.role.domain.RoleRepository;
import ru.tagallteam.user.application.role.mapper.RoleMapper;
import ru.tagallteam.user.application.role.model.RoleDto;
import ru.tagallteam.user.error.ErrorDescriptor;

import java.util.List;

@Service
@AllArgsConstructor
public class RoleService {

    private final RoleRepository roleRepository;

    private final RoleMapper roleMapper;

    public List<RoleDto> getRoles() {
        return roleRepository.findAll().stream().map(roleMapper::toDto).toList();
    }

    public RoleDto getRoleDto(Long roleId) {
        return roleMapper.toDto(getRole(roleId));
    }

    public Role getRole(Long roleId) {
        ErrorDescriptor.ROLE_NOT_FOUND.throwIsFalse(roleRepository.existsById(roleId));
        return roleRepository.getReferenceById(roleId);
    }
}
