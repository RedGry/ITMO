package ru.tagallteam.user.utils;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.tagallteam.user.configuration.JwtConfig;

@Component
@RequiredArgsConstructor
public class JwtUtils {
    private final JwtConfig jwtConfig;

    public boolean validateToken(String token) {
        try {
            Jwts.parser().setSigningKey(jwtConfig.getJwtSecret())
                    .parseClaimsJws(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public String getWordForToken(String token) {
        Claims claims = Jwts.parser().setSigningKey(jwtConfig.getJwtSecret())
                .parseClaimsJws(token).getBody();
        return claims.getSubject();
    }

}
