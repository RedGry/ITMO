package ru.tagallteam.user.configuration.auth.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import ru.tagallteam.user.configuration.auth.model.AuthDto;
import ru.tagallteam.user.configuration.auth.model.Status;

@FeignClient(name = "auth-service", url = "${service.auth-service.url}")
public interface AuthServiceApi {

    @PostMapping("/auth/is-login")
    Status isLogin(@RequestBody AuthDto authDto);
}
