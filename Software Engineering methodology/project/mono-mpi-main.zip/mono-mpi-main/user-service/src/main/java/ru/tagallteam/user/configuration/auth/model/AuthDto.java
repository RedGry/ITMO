package ru.tagallteam.user.configuration.auth.model;

import lombok.Data;

@Data
public class AuthDto {
    String token;
}
