package ru.tagallteam.user.application.role;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.tagallteam.user.application.role.model.RoleDto;
import ru.tagallteam.user.application.role.service.RoleService;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/role")
public class RoleController {

    private final RoleService roleService;

    @GetMapping
    public List<RoleDto> getRoles() {
        return roleService.getRoles();
    }

    @GetMapping("/{roleId}")
    public RoleDto getRole(@PathVariable Long roleId) {
        return roleService.getRoleDto(roleId);
    }
}
