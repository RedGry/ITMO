package ru.tagallteam.user.application.user;

import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.tagallteam.user.application.user.model.PasswordDto;
import ru.tagallteam.user.application.user.model.UserCreateDto;
import ru.tagallteam.user.application.user.model.UserDto;
import ru.tagallteam.user.application.user.service.UserService;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/user")
public class UserController {

    private final UserService userService;

    @PostMapping
    public UserDto create(@RequestBody UserCreateDto userCreateDto) {
        return userService.create(userCreateDto);
    }

    @GetMapping("/{userId}")
    public UserDto getUser(@PathVariable Long userId) {
        return userService.getUser(userId);
    }

    @GetMapping
    public List<UserDto> getUsers(@RequestParam Long page, @RequestParam Long limit) {
        return userService.getUsers(page, limit);
    }

    @PutMapping("/{userId}")
    public UserDto updateUser(@PathVariable Long userId, @RequestBody UserCreateDto userCreateDto) {
        return userService.updateUser(userId, userCreateDto);
    }

    @PutMapping("/{userId}/generate/password")
    public PasswordDto generatePassword(@PathVariable Long userId) {
        return userService.generatePassword(userId);
    }

    @GetMapping("/login/{login}")
    public UserDto login(@PathVariable String login) {
        return userService.login(login);
    }

    @GetMapping("{userId}/login/pass")
    public PasswordDto loginPass(@PathVariable Long userId) {
        return userService.loginPass(userId);
    }

    @GetMapping("/free")
    public List<UserDto> getFreeUsers(@RequestParam List<Long> notFreeIds) {
        return userService.getFreeUsers(notFreeIds);
    }

}
