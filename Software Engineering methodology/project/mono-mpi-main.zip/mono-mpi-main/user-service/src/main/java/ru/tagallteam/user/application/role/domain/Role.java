package ru.tagallteam.user.application.role.domain;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import ru.tagallteam.user.application.user.domain.User;

import java.util.List;

@Getter
@Setter
@Entity
@ToString(of = "id")
@Table(name = "role")
public class Role {
    @Id
    private Long id;
    private String name;
    @OneToMany(mappedBy = "role", cascade = CascadeType.ALL)
    private List<User> users;
}
