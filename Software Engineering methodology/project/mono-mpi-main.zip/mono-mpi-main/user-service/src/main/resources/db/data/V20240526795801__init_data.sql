insert into role(id, name)
values (1, 'Агент'),
       (2, 'Вариант'),
       (3, 'Менеджер'),
       (4, 'Помощник'),
       (5, 'Управляющий станком'),
       (6, 'Администратор');

insert into profile (id, role_id, name, login, password)
values (nextval('profile_seq'), 1, 'Agent', 'agent',
        '{bcrypt}$2a$10$RyR5w3vGvjmAMuxLVpibwunMPkUIICGNVeTgvYxjHrF1LTFxbox26'),
       (nextval('profile_seq'), 2, 'Variant', 'variant',
        '{bcrypt}$2a$10$T65SWsMIl5tsMxHkrm.lVueBoyK2vyhAmC1g7u0Azi4URXRk9/r7C'),
       (nextval('profile_seq'), 3, 'Manager', 'manager',
        '{bcrypt}$2a$10$Cy7ynvu9nBAWcR7MnK41w.M/0PALptWkz.6PZpbr6nin/t.mBKZJS'),
       (nextval('profile_seq'), 4, 'Helper', 'helper',
        '{bcrypt}$2a$10$8Grlciu9OkF1.xOKfmRmB.XOrqHRAu3vynEEKuSOAAWDrkEOP4elS'),
       (nextval('profile_seq'), 5, 'Machine Manager', 'machine',
        '{bcrypt}$2a$10$Unl0JILfA/o78DYj/C/txeKcyPLb7VsZ5OAWrUUzsG/JrQbAxzQDS'),
       (nextval('profile_seq'), 6, 'Admin', 'admin',
        '{bcrypt}$2a$10$81nuwVEeHrbVkbYQpTa9K.rAsUVDAv28TAZx9WlJ2pnLQZa7QkCK.');