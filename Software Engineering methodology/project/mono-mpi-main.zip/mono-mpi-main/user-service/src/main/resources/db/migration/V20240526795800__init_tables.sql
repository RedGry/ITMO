create table role
(
    id   int primary key,
    name varchar not null
);

create sequence profile_seq;

create table profile
(
    id       int primary key,
    role_id  int references role (id),
    name     varchar(256) not null,
    login    varchar(256) not null unique,
    password text
);