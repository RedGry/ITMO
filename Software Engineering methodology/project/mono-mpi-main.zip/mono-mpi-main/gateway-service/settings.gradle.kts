rootProject.name = "gateway-service"
