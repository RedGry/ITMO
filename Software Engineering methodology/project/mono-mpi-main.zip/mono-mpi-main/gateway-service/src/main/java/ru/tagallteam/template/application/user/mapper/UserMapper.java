package ru.tagallteam.template.application.user.mapper;

import org.springframework.stereotype.Component;
import ru.tagallteam.template.application.role.model.RoleDto;
import ru.tagallteam.template.application.user.model.PasswordDto;
import ru.tagallteam.template.application.user.model.UserDto;
import ru.tagallteam.template.configuration.user.model.UserCreateDto;

@Component
public class UserMapper {
    public UserDto toUserDto(ru.tagallteam.template.configuration.user.model.UserDto userDtoApi) {
        UserDto userDto = new UserDto();
        userDto.setId(userDtoApi.getId());
        userDto.setLogin(userDtoApi.getLogin());
        userDto.setName(userDtoApi.getName());
        userDto.setRole(roleDto(userDtoApi.getRole()));
        return userDto;
    }

    public RoleDto roleDto(ru.tagallteam.template.configuration.user.model.RoleDto roleDtoApi) {
        RoleDto roleDto = new RoleDto();
        roleDto.setId(roleDtoApi.getId());
        roleDto.setName(roleDtoApi.getName());
        return roleDto;
    }

    public UserCreateDto toUserCreateDtoApi(ru.tagallteam.template.application.user.model.UserCreateDto userDto) {
        UserCreateDto userCreateDto = new UserCreateDto();
        userCreateDto.setLogin(userDto.getLogin());
        userCreateDto.setName(userDto.getName());
        if (userDto.getPassword() != null) {
            userCreateDto.setPassword(userDto.getPassword());
        }
        userCreateDto.setRoleId(userDto.getRoleId());
        return userCreateDto;
    }

    public PasswordDto passwordDto(ru.tagallteam.template.configuration.user.model.PasswordDto passwordDtoApi) {
        PasswordDto passwordDto = new PasswordDto();
        passwordDto.setPassword(passwordDtoApi.getPassword());
        return passwordDto;
    }
}
