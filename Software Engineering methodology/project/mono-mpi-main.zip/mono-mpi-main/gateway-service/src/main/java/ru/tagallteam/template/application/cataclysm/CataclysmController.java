package ru.tagallteam.template.application.cataclysm;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.tagallteam.template.application.cataclysm.model.CataclysmCreateDto;
import ru.tagallteam.template.application.cataclysm.model.CataclysmDto;
import ru.tagallteam.template.application.cataclysm.service.CataclysmService;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/cataclysm")
public class CataclysmController {

    private final CataclysmService cataclysmService;

    @Operation(
            summary = "Получение катаклизмов",
            description = "Позволяет получить катаклизмы постранично с указанием кол. элементов на странице"
    )
    @GetMapping()
    public List<CataclysmDto> getCataclysms(
            @Parameter(description = "Номер страници", example = "0")
            @RequestParam Long page,
            @Parameter(description = "Количество элементов на странице", example = "10")
            @RequestParam Long limit) {
        return cataclysmService.getCataclysms(page, limit);
    }

    @Operation(
            summary = "Получение катаклизма",
            description = "Позволяет получить катаклизм по ид"
    )
    @GetMapping("/{cataclysmId}")
    public CataclysmDto getCataclysm(@Parameter(description = "Ид катаклизма", example = "1")
                                     @PathVariable Long cataclysmId
    ) {
        return cataclysmService.getCataclysm(cataclysmId);
    }

    @Operation(
            summary = "Создание катаклизма",
            description = "Позволяет создать катаклизм"
    )
    @PostMapping()
    public CataclysmDto createCataclysm(@Parameter(description = "Модель создания катаклизма")
                                        @RequestBody CataclysmCreateDto cataclysmDto
    ) {
        return cataclysmService.createCataclysm(cataclysmDto);
    }

    @Operation(
            summary = "Обновление катаклизма",
            description = "Позволяет обновить данные катаклизма"
    )
    @PutMapping("/{cataclysmId}")
    public CataclysmDto updateCataclysm(@Parameter(description = "Модель обновления катаклизма")
                                        @RequestBody CataclysmCreateDto cataclysmDto,
                                        @Parameter(description = "Ид катаклизма", example = "1")
                                        @PathVariable Long cataclysmId) {
        return cataclysmService.updateCataclysm(cataclysmId, cataclysmDto);
    }

    @Operation(
            summary = "Удаленеи катаклизма",
            description = "Позволяет удалить катаклизм"
    )
    @DeleteMapping("/{cataclysmId}")
    public void deleteCataclysm(@Parameter(description = "Ид катаклизма", example = "1") @PathVariable Long cataclysmId) {
        cataclysmService.deleteCataclysm(cataclysmId);
    }
}
