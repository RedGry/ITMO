package ru.tagallteam.template.configuration.auth.configuration;

import com.fasterxml.jackson.databind.ObjectMapper;
import feign.codec.ErrorDecoder;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.DefaultUriBuilderFactory;
import ru.tagallteam.template.configuration.auth.service.AuthServiceApi;
import ru.tagallteam.template.configuration.machine.configuration.MachineConfigurationProperties;
import ru.tagallteam.template.utils.FeignUtil;

@Configuration
@RequiredArgsConstructor
public class AuthConfiguration {
    private final ErrorDecoder errorDecoder;

    private final ObjectMapper objectMapper;

    private final MachineConfigurationProperties properties;

    /**
     * Шаблон обслуживания.
     *
     * @return {@link RestTemplate}.
     */
    @Bean
    @Qualifier("AuthServiceRestTemplate")
    @ConditionalOnMissingBean(name = "AuthServiceRestTemplate")
    public RestTemplate AuthServiceRestTemplate() {
        SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
        clientHttpRequestFactory.setConnectTimeout(properties.getTimout());
        clientHttpRequestFactory.setReadTimeout(properties.getTimout());
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.setUriTemplateHandler(new DefaultUriBuilderFactory(properties.getUrl()));
        restTemplate.getMessageConverters().stream()
                .filter(it -> it instanceof MappingJackson2HttpMessageConverter)
                .map(it -> (MappingJackson2HttpMessageConverter) it)
                .forEach(it -> it.setObjectMapper(objectMapper));
        return restTemplate;
    }

    @Bean
    public AuthServiceApi authServiceApi(ObjectFactory<HttpMessageConverters> messageConverters) {
        return FeignUtil.buildFeignClient(AuthServiceApi.class, properties.getUrl(), messageConverters, errorDecoder);
    }
}
