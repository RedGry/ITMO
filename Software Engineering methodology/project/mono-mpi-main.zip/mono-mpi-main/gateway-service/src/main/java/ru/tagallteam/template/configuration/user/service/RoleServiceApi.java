package ru.tagallteam.template.configuration.user.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import ru.tagallteam.template.configuration.user.model.RoleDto;

import java.util.List;

@FeignClient(name = "role-service", url = "${service.user-service.url}")
public interface RoleServiceApi {
    @GetMapping("/role")
    List<RoleDto> getRoles();

    @GetMapping("/role/{roleId}")
    RoleDto getRole(@PathVariable Long roleId);
}
