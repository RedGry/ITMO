package ru.tagallteam.template.configuration.user.model;

import lombok.Data;

@Data
public class UserDto {
    private Long id;
    private String name;
    private String login;
    private RoleDto role;
}
