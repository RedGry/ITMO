package ru.tagallteam.template.application.machine.service;

import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import ru.tagallteam.template.configuration.machine.model.BufferDto;
import ru.tagallteam.template.configuration.machine.model.TimeDto;
import ru.tagallteam.template.configuration.machine.service.MachineServiceApi;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
public class MachineService {

    private final MachineServiceApi machineServiceApi;

    public Resource downloadGraphic(LocalDate start, LocalDate stop) {
        return null;
    }

    public void updateBufferSize(Long buffer) {
        machineServiceApi.setBufferSize(buffer);
    }

    public void updateClearTime(String duration) {
        machineServiceApi.clearTime(duration);
    }

    public TimeDto getTime() {
        return machineServiceApi.getTime();
    }

    public BufferDto getBuffer() {
        return machineServiceApi.getBuffer();
    }

}
