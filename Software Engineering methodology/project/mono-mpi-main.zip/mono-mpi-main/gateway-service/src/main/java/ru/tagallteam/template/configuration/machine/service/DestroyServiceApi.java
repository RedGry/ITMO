package ru.tagallteam.template.configuration.machine.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "destroy-service", url = "${service.machine-service.url}")
public interface DestroyServiceApi {
    @PutMapping("/destroy")
    void addDestroyQueue(@RequestParam Long timelineId);

    @DeleteMapping("/destroy")
    void allDestroyQueue();
}
