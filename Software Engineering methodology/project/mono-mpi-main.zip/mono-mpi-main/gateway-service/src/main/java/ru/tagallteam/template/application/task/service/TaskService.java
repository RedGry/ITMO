package ru.tagallteam.template.application.task.service;

import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import ru.tagallteam.template.application.task.mapper.TaskMapper;
import ru.tagallteam.template.application.task.model.TaskCreateDto;
import ru.tagallteam.template.application.task.model.TaskDto;
import ru.tagallteam.template.configuration.cataclism.model.CataclysmDto;
import ru.tagallteam.template.configuration.cataclism.service.CataclysmServiceApi;
import ru.tagallteam.template.configuration.machine.service.DestroyServiceApi;
import ru.tagallteam.template.configuration.task.service.TaskServiceApi;
import ru.tagallteam.template.configuration.user.model.UserDto;

import java.util.List;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
public class TaskService {

    private final TaskServiceApi taskServiceApi;

    private final CataclysmServiceApi cataclysmServiceApi;

    private final DestroyServiceApi destroyServiceApi;

    private final TaskMapper taskMapper;

    public TaskDto createTask(TaskCreateDto taskCreateDto) {
        return taskMapper.toTaskDto(taskServiceApi.createTask(taskMapper.toTaskServiceDto(taskCreateDto)));
    }

    public TaskDto updateTask(TaskCreateDto taskCreateDto, Long taskId) {
        return taskMapper.toTaskDto(taskServiceApi.updateTask(taskMapper.toTaskServiceDto(taskCreateDto), taskId));
    }

    public TaskDto getTaskById(Long taskId) {
        return taskMapper.toTaskDto(taskServiceApi.getTaskById(taskId));
    }

    public List<TaskDto> getTasks(Long page, Long limit) {
        Stream<TaskDto> taskDtoStream = taskServiceApi.getTasks(page, limit).stream().map(taskMapper::toTaskDto)
                .filter(taskDto -> !taskDto.getCataclysm().getId().equals(-1L));
        UserDto userDto = (UserDto) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if(userDto.getRole().getId().equals(6L) || userDto.getRole().getId().equals(3L)) {
            return taskDtoStream.toList();
        }
        return taskDtoStream
                .filter(taskDto -> taskDto.getExecutor().getId().equals(userDto.getId())).toList();
    }

    public TaskDto setTaskExecutor(Long taskId, Long executorId) {
        return taskMapper.toTaskDto(taskServiceApi.setTaskExecutor(taskId, executorId));
    }

    public TaskDto startTask(Long taskId) {
        return taskMapper.toTaskDto(taskServiceApi.startTask(taskId));
    }

    public TaskDto completedTask(Long taskId) {
        TaskDto taskDto = taskMapper.toTaskDto(taskServiceApi.completedTask(taskId));
        if (taskDto.getStatus().getId().equals(4L)) {
            cataclysmServiceApi.deleteCataclysm(taskDto.getCataclysm().getId());
        }
        return taskDto;
    }

    public TaskDto collectResources(Long taskId) {
        ru.tagallteam.template.configuration.task.model.TaskDto taskDto = taskServiceApi.getTaskById(taskId);
        CataclysmDto cataclysmDto = cataclysmServiceApi.getCataclysm(taskDto.getCataclysmId());
        destroyServiceApi.addDestroyQueue(cataclysmDto.getTimeline().getId());
        return taskMapper.toTaskDto(taskServiceApi.collectResources(taskId, cataclysmDto.getTimeline().getId()));
    }

    public void deleteTask(Long taskId) {
        taskServiceApi.deleteTasks(taskId);
    }
}
