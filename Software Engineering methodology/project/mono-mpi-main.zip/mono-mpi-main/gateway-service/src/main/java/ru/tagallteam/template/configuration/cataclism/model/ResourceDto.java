package ru.tagallteam.template.configuration.cataclism.model;

import lombok.Data;

@Data
public class ResourceDto {
    private Long id;
    private String name;
    private Long count;
}
