package ru.tagallteam.template.application.cataclysm.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class CataclysmTypeDto {
    @Schema(description = "Ид типа катаклизма", example = "1")
    private Long id;
    @Schema(description = "Нащвание типа катаклизма", example = "Слабый")
    private String name;
}
