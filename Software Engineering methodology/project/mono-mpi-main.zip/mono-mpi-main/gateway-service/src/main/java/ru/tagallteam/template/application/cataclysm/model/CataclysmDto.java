package ru.tagallteam.template.application.cataclysm.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import ru.tagallteam.template.application.common.Constants;
import ru.tagallteam.template.configuration.cataclism.model.ResourceDto;

import java.time.LocalTime;
import java.util.List;

@Data
public class CataclysmDto {
    @Schema(description = "Ид катаклизма", example = "1")
    private Long id;
    @Schema(description = "Название места", example = "Санкт-Петербург")
    private String place;
    @Schema(description = "Время возникновения катаклизма", example = "12:30:23")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.TIME_FORMAT)
    private LocalTime time;
    @Schema(description = "Описание катаклизма", example = "Описание катаклизма")
    private String description;
    @Schema(description = "Тип катаклизма")
    private CataclysmTypeDto type;
    @Schema(description = "Ресурсы")
    private List<ResourceDto> resources;
    @Schema(description = "Стоимость всех ресурсов")
    private Long costOfResources;
}
