package ru.tagallteam.template.error;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.util.ObjectUtils;
import ru.tagallteam.template.error.exception.ApplicationException;
import ru.tagallteam.template.error.model.ApplicationError;

@Getter
@AllArgsConstructor
public enum ErrorDescriptor {

    PASSWORD_ERROR("Пароль неверный", HttpStatus.UNAUTHORIZED),
    UNAUTHORIZED_ACCESS("Неавторизованный доступ", HttpStatus.UNAUTHORIZED),
    ACCESS_DENIED("Недостаточно прав для доступа к ресурсу", HttpStatus.FORBIDDEN),
    DATA_BASE_ERROR("Ошибка взаимодействия с бд", HttpStatus.BAD_REQUEST),
    INTERNAL_SERVER_ERROR("Неожиданная ошибка сервиса", HttpStatus.INTERNAL_SERVER_ERROR),
    NOT_FOUND("Запрошенный ресурс (интерфейс) не существует", HttpStatus.NOT_FOUND);


    private final String message;


    private final HttpStatus status;

    public void exception() {
        throw ApplicationException.of(applicationError());
    }

    public ApplicationException callExceptionModel() {
        return ApplicationException.of(applicationError());
    }

    public void throwIsTrue(Boolean flag) {
        if (flag) {
            exception();
        }
    }

    public void throwIsFalse(Boolean flag) {
        if (!flag) {
            exception();
        }
    }

    public void throwIsNull(Object object) {
        if (ObjectUtils.isEmpty(object)) {
            exception();
        }
    }

    public ApplicationError applicationError() {
        return new ApplicationError(this.message, this.status);
    }

}
