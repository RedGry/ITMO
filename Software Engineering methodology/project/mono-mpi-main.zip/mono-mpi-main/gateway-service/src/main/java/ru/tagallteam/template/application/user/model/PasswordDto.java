package ru.tagallteam.template.application.user.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class PasswordDto {
    @Schema(description = "Сгенерированый пароль")
    private String password;
}
