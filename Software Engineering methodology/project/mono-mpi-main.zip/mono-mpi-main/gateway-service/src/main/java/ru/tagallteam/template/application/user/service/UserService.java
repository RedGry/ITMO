package ru.tagallteam.template.application.user.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import ru.tagallteam.template.application.cataclysm.model.CataclysmDto;
import ru.tagallteam.template.application.cataclysm.service.CataclysmService;
import ru.tagallteam.template.application.user.mapper.UserMapper;
import ru.tagallteam.template.application.user.model.PasswordDto;
import ru.tagallteam.template.application.user.model.UserCreateDto;
import ru.tagallteam.template.application.user.model.UserDto;
import ru.tagallteam.template.configuration.task.service.TaskServiceApi;
import ru.tagallteam.template.configuration.user.service.UserServiceApi;
import ru.tagallteam.template.error.exception.ApplicationException;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserService {
    private final UserServiceApi userServiceApi;
    private final UserMapper userMapper;
    private final TaskServiceApi taskServiceApi;
    private final CataclysmService cataclysmService;

    public UserDto create(UserCreateDto userCreateDto) {
        return userMapper.toUserDto(userServiceApi.create(userMapper.toUserCreateDtoApi(userCreateDto)));
    }

    public UserDto getUser(Long userId) {
        return userMapper.toUserDto(userServiceApi.getUser(userId));
    }

    public List<UserDto> getUsers(Long page, Long limit) {
        return userServiceApi.getUsers(page, limit).stream().map(userMapper::toUserDto).toList();
    }

    public UserDto updateUser(Long userId, UserCreateDto userCreateDto) {
        return userMapper.toUserDto(userServiceApi.updateUser(userId, userMapper.toUserCreateDtoApi(userCreateDto)));
    }

    public PasswordDto generatePassword(Long userId) {
        return userMapper.passwordDto(userServiceApi.generatePassword(userId));
    }

    public List<UserDto> getFreeUsers() {
        return userServiceApi.getFreeUsers(userNotFreeIds(0L, 1000000000L)).stream()
                .map(userMapper::toUserDto).toList();
    }

    private List<Long> userNotFreeIds(Long page, Long limit) {
        Map<Long, Long> executorTaskCount = taskServiceApi.getTasks(page, limit).stream()
                .filter(it -> it.getStatusDto().getId().equals(1L) ||
                        it.getStatusDto().getId().equals(2L) ||
                        it.getStatusDto().getId().equals(3L)
                )
                .filter(it -> isShowByCataclysm(it.getCataclysmId()))
                .collect(Collectors.groupingBy(
                                ru.tagallteam.template.configuration.task.model.TaskDto::getExecutorId,
                                Collectors.counting()
                        )
                );
        return executorTaskCount.entrySet().stream()
                .filter(entry -> entry.getValue() > 2)
                .map(Map.Entry::getKey)
                .toList();
    }

    private boolean isShowByCataclysm(Long cataclysmId) {
        try {
            CataclysmDto cataclysmDto = cataclysmService.getCataclysm(cataclysmId);
            if (CollectionUtils.isEmpty(cataclysmDto.getResources())) {
                cataclysmDto.setId(-1L);
                return false;
            }
            return true;
        } catch (ApplicationException ex) {
            return false;
        }
    }

}
