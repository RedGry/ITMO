package ru.tagallteam.template.configuration.task.model;

import lombok.Data;

@Data
public class TaskDto {
    private Long id;
    private Long executorId;
    private Long cataclysmId;
    private String description;
    private StatusDto statusDto;
}
