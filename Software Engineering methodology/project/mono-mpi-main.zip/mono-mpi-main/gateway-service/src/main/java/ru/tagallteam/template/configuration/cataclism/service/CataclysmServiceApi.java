package ru.tagallteam.template.configuration.cataclism.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import ru.tagallteam.template.configuration.cataclism.model.CataclysmCreateDto;
import ru.tagallteam.template.configuration.cataclism.model.CataclysmDto;

import java.util.List;

@FeignClient(name = "cataclysm-service", url = "${service.cataclysm-service.url}")
public interface CataclysmServiceApi {
    @PostMapping("/cataclysm")
    CataclysmDto createCataclysm(@RequestBody CataclysmCreateDto cataclysmCreateDto);

    @GetMapping("/cataclysm")
    List<CataclysmDto> getCataclysms(@RequestParam Long page, @RequestParam Long limit);

    @GetMapping("/cataclysm/{cataclysmId}")
    CataclysmDto getCataclysm(@PathVariable Long cataclysmId);

    @PutMapping("/cataclysm/{cataclysmId}")
    CataclysmDto updateCataclysm(@PathVariable Long cataclysmId, @RequestBody CataclysmCreateDto cataclysmCreateDto);

    @DeleteMapping("/cataclysm/{cataclysmId}")
    void deleteCataclysm(@PathVariable Long cataclysmId);
}
