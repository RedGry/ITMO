package ru.tagallteam.template.application.task.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class TaskStatusDto {
    @Schema(description = "Ид статуса", example = "1")
    private Long id;
    @Schema(description = "Название статуса", example = "Активно")
    private String name;
}
