package ru.tagallteam.template.application.task.mapper;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import ru.tagallteam.template.application.cataclysm.model.CataclysmDto;
import ru.tagallteam.template.application.cataclysm.service.CataclysmService;
import ru.tagallteam.template.application.task.model.TaskDto;
import ru.tagallteam.template.application.task.model.TaskStatusDto;
import ru.tagallteam.template.application.user.model.UserDto;
import ru.tagallteam.template.application.user.service.UserService;
import ru.tagallteam.template.configuration.task.model.StatusDto;
import ru.tagallteam.template.configuration.task.model.TaskCreateDto;
import ru.tagallteam.template.error.exception.ApplicationException;

@Component
@Slf4j
@RequiredArgsConstructor
public class TaskMapper {

    private final CataclysmService cataclysmService;

    private final UserService userService;

    public TaskCreateDto toTaskServiceDto(ru.tagallteam.template.application.task.model.TaskCreateDto taskCreateDto) {
        TaskCreateDto taskDto = new TaskCreateDto();
        taskDto.setCataclysmId(taskCreateDto.getCataclysmId());
        taskDto.setDescription(taskCreateDto.getDescription());
        taskDto.setExecutorId(taskCreateDto.getExecutorId());
        return taskDto;
    }

    public TaskDto toTaskDto(ru.tagallteam.template.configuration.task.model.TaskDto taskDto) {
        TaskDto task = new TaskDto();
        task.setId(taskDto.getId());
        task.setDescription(taskDto.getDescription());
        try {
            CataclysmDto cataclysmDto = cataclysmService.getCataclysm(taskDto.getCataclysmId());
            if (CollectionUtils.isEmpty(cataclysmDto.getResources()) && !taskDto.getStatusDto().getId().equals(6L)) {
                cataclysmDto.setId(-1L);
            }
            task.setCataclysm(cataclysmDto);
        } catch (ApplicationException ex) {
            CataclysmDto cataclysmDto = new CataclysmDto();
            cataclysmDto.setId(-2L);
            cataclysmDto.setDescription("Катаклизм завершен");
            task.setCataclysm(cataclysmDto);
        }
        try {
            task.setExecutor(userService.getUser(taskDto.getExecutorId()));
        } catch (ApplicationException ex) {
            task.setExecutor(new UserDto());
        }
        task.setStatus(toTaskStatusDto(taskDto.getStatusDto()));
        return task;
    }

    private TaskStatusDto toTaskStatusDto(StatusDto statusDto) {
        TaskStatusDto taskStatusDto = new TaskStatusDto();
        taskStatusDto.setId(statusDto.getId());
        taskStatusDto.setName(statusDto.getName());
        return taskStatusDto;
    }
}
