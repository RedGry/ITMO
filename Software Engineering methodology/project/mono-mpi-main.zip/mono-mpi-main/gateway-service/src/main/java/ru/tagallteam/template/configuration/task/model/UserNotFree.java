package ru.tagallteam.template.configuration.task.model;

import lombok.Data;

import java.util.List;

@Data
public class UserNotFree {
    List<Long> userIds;
}
