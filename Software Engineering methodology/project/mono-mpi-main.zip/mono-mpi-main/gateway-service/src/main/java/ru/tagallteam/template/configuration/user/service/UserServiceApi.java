package ru.tagallteam.template.configuration.user.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import ru.tagallteam.template.configuration.user.model.PasswordDto;
import ru.tagallteam.template.configuration.user.model.UserCreateDto;
import ru.tagallteam.template.configuration.user.model.UserDto;

import java.util.List;

@FeignClient(name = "user-service", url = "${service.user-service.url}")
public interface UserServiceApi {
    @PostMapping("/user")
    UserDto create(@RequestBody UserCreateDto userCreateDto);

    @GetMapping("/user/{userId}")
    UserDto getUser(@PathVariable Long userId);

    @GetMapping("/user")
    List<UserDto> getUsers(@RequestParam Long page, @RequestParam Long limit);

    @PutMapping("/user/{userId}")
    UserDto updateUser(@PathVariable Long userId, @RequestBody UserCreateDto userCreateDto);

    @PutMapping("/user/{userId}/generate/password")
    PasswordDto generatePassword(@PathVariable Long userId);

    @GetMapping("/user/login/{login}")
    UserDto login(@PathVariable String login);

    @GetMapping("/user/{userId}/login/pass")
    PasswordDto loginPass(@PathVariable Long userId);

    @GetMapping("/user/free")
    List<UserDto> getFreeUsers(@RequestParam List<Long> notFreeIds);
}
