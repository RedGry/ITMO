package ru.tagallteam.template.configuration.cataclism.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import ru.tagallteam.template.application.common.Constants;

import java.time.LocalTime;

@Data
public class CataclysmCreateDto {
    private String place;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern = Constants.TIME_FORMAT)
    private LocalTime time;
    private String description;
    private Long typeId;
}
