package ru.tagallteam.template.application.auth;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.RequiredArgsConstructor;
import lombok.SneakyThrows;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.tagallteam.template.application.auth.model.AccessDto;
import ru.tagallteam.template.application.auth.model.AuthDto;
import ru.tagallteam.template.application.auth.model.TokenDto;
import ru.tagallteam.template.configuration.auth.service.AuthServiceApi;
import ru.tagallteam.template.configuration.user.model.PasswordDto;
import ru.tagallteam.template.configuration.user.model.UserDto;
import ru.tagallteam.template.configuration.user.service.UserServiceApi;
import ru.tagallteam.template.error.ErrorDescriptor;
import ru.tagallteam.template.utils.JwtUtils;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/auth")
public class AuthController {

    private final AuthServiceApi authServiceApi;

    private final JwtUtils jwtUtils;

    private final UserServiceApi userServiceApi;

    private final ObjectMapper objectMapper;

    private final ru.tagallteam.template.application.user.service.UserService userServiceGateway;

    private final PasswordEncoder passwordEncoder = PasswordEncoderFactories.createDelegatingPasswordEncoder();

    @Operation(
            summary = "Авторизация пользователя",
            description = "Позволяет авторизировать пользователя"
    )
    @PostMapping("/login")
    public TokenDto login(@Parameter(description = "Модель авторизации")
                          @RequestBody AuthDto authDto
    ) {
        UserDto userDto = userServiceApi.login(authDto.getLogin());
        PasswordDto passwordDto = userServiceApi.loginPass(userDto.getId());
        ErrorDescriptor.PASSWORD_ERROR.throwIsFalse(passwordEncoder.matches(authDto.getPass(), passwordDto.getPassword()));
        String token = jwtUtils.generateToken(userDto);
        TokenDto tokenDto = new TokenDto();
        tokenDto.setAuthToken(token);
        tokenDto.setAccessToken(token);
        tokenDto.setUserDto(userServiceGateway.getUser(userDto.getId()));
        ru.tagallteam.template.configuration.auth.model.AuthDto authDtoApi = new ru.tagallteam.template.configuration.auth.model.AuthDto();
        authDtoApi.setToken(token);
        authServiceApi.login(authDtoApi, userDto.getId());
        return tokenDto;
    }

    @Operation(
            summary = "Выход из системы",
            description = "Позволяет выйти"
    )
    @PostMapping("/logout")
    public void logout(@Parameter(description = "Модель токена, для выхода")
                       @RequestBody AccessDto accessDto
    ) {
        ru.tagallteam.template.configuration.auth.model.AuthDto authDtoApi = new ru.tagallteam.template.configuration.auth.model.AuthDto();
        authDtoApi.setToken(accessDto.getAccessToken());
        authServiceApi.logout(authDtoApi);
    }

    @SneakyThrows
    @Operation(
            summary = "Обновление токена",
            description = "Позволяет обновить токен"
    )
    @PostMapping("/update")
    public TokenDto update(@Parameter(description = "Модель токена, для обновления доступа")
                           @RequestBody AccessDto accessDto
    ) {
        UserDto userDto = objectMapper.readValue(jwtUtils.getWordForToken(accessDto.getAccessToken()), UserDto.class);
        String token = jwtUtils.generateToken(userDto);
        TokenDto tokenDto = new TokenDto();
        tokenDto.setAuthToken(token);
        tokenDto.setAccessToken(token);
        tokenDto.setUserDto(userServiceGateway.getUser(userDto.getId()));
        logout(accessDto);
        ru.tagallteam.template.configuration.auth.model.AuthDto authDtoApi = new ru.tagallteam.template.configuration.auth.model.AuthDto();
        authDtoApi.setToken(token);
        authServiceApi.login(authDtoApi, userDto.getId());
        return tokenDto;
    }
}
