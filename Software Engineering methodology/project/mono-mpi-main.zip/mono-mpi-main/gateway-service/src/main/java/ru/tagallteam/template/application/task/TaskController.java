package ru.tagallteam.template.application.task;

import java.util.List;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.tagallteam.template.application.task.model.TaskCreateDto;
import ru.tagallteam.template.application.task.model.TaskDto;
import ru.tagallteam.template.application.task.service.TaskService;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/task")
public class TaskController {

    private final TaskService taskService;

    @Operation(
            summary = "Получение заданий",
            description = "Позволяет получить задания постранично с указанием кол. элементов на странице"
    )
    @GetMapping()
    public List<TaskDto> getTasks(
            @Parameter(description = "Номер страници", example = "0")
            @RequestParam Long page,
            @Parameter(description = "Количество элементов на странице", example = "10")
            @RequestParam Long limit
    ) {
        return taskService.getTasks(page, limit);
    }

    @Operation(
            summary = "Получение задания",
            description = "Позволяет получить задание по ид"
    )
    @GetMapping("/{taskId}")
    public TaskDto getTask(
            @Parameter(description = "Ид задания", example = "1")
            @PathVariable Long taskId
    ) {
        return taskService.getTaskById(taskId);
    }

    @Operation(
            summary = "Создание задания",
            description = "Позволяет создать задание"
    )
    @PostMapping()
    public TaskDto createTask(@RequestBody TaskCreateDto taskCreate) {
        return taskService.createTask(taskCreate);
    }

    @Operation(
            summary = "Обновление задания",
            description = "Позволяет обновить задание"
    )
    @PutMapping("/{taskId}")
    public TaskDto updateTask(@RequestBody TaskCreateDto taskCreate,
                              @Parameter(description = "Ид задания", example = "1")
                              @PathVariable Long taskId) {
        return taskService.updateTask(taskCreate, taskId);
    }

    @Operation(
            summary = "Назначить задания",
            description = "Позволяет назначить задание на пользователя"
    )
    @PutMapping("/{taskId}/set/user/{userId}")
    public TaskDto setTaskForUser(
            @Parameter(description = "Ид задания", example = "1")
            @PathVariable Long taskId,
            @PathVariable Long userId) {
        return taskService.setTaskExecutor(taskId, userId);
    }

    @Operation(
            summary = "Начать выполнение задания",
            description = "Позволяет инициализировать выполнение задание"
    )
    @PutMapping("/{taskId}/start")
    public TaskDto startTask(
            @Parameter(description = "Ид задания", example = "1")
            @PathVariable Long taskId
    ) {
        return taskService.startTask(taskId);
    }

    @Operation(
            summary = "Завершение задания",
            description = "Позволяет завершить задание"
    )
    @PutMapping("/{taskId}/completed")
    public TaskDto completedPositivelyTask(
            @Parameter(description = "Ид задания", example = "1")
            @PathVariable Long taskId
    ) {
        return taskService.completedTask(taskId);
    }

    @Operation(
            summary = "Сбор ресурсов",
            description = "Позволяет инициализировать сбор ресурсов"
    )
    @PutMapping("/{taskId}/collect")
    public TaskDto collectResources(
            @Parameter(description = "Ид задания", example = "1")
            @PathVariable Long taskId
    ) {
        return taskService.collectResources(taskId);
    }

    @DeleteMapping("/{taskId}")
    public void deleteTask(@PathVariable Long taskId) {
        taskService.deleteTask(taskId);
    }
}
