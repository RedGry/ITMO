package ru.tagallteam.template.configuration.machine.model;

import lombok.Data;

/**
 * @author Iurii Babalin (ueretz)
 */
@Data
public class TimeDto {
    private String time;
}
