package ru.tagallteam.template.application.machine;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.RequiredArgsConstructor;
import org.springframework.core.io.Resource;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import ru.tagallteam.template.application.machine.service.MachineService;
import ru.tagallteam.template.configuration.machine.model.BufferDto;
import ru.tagallteam.template.configuration.machine.model.TimeDto;
import ru.tagallteam.template.configuration.machine.service.DestroyServiceApi;

import java.time.LocalDate;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/machine")
public class MachineController {

    private final MachineService machineService;

    private final DestroyServiceApi destroyServiceApi;

    @Operation(
            summary = "Получение файла с данными о работе станка",
            description = "Позволяет получить информацию о работе станка. Вернет документ excel"
    )
    @PostMapping("/graphic")
    public Resource downloadGraphic(
            @Parameter(description = "Дата с которой мы начинаем собирать данные", example = "10.02.2024")
            @RequestParam
            @DateTimeFormat(pattern = "dd.MM.yyyy")
            LocalDate start,
            @Parameter(description = "Дата до которой мы собирать данные", example = "20.02.2024")
            @RequestParam
            @DateTimeFormat(pattern = "dd.MM.yyyy")
            LocalDate stop
    ) {
        return machineService.downloadGraphic(start, stop);
    }

    @Operation(
            summary = "Установка буффера",
            description = "Позволяет установить размер буффера для станка"
    )
    @PutMapping("/buffer/size")
    public void updateBufferSize(@Parameter(description = "Размер буффера", example = "10")
                                 @RequestParam Long buffer
    ) {
        machineService.updateBufferSize(buffer);
    }

    @Operation(
            summary = "Установка время очистки",
            description = "Позволяет установить время очистки таймлайнов станком"
    )
    @PutMapping("/clear/time")
    public void updateClearTime(@Parameter(description = "Время через которое происходит очистка", example = "40s")
                                @RequestParam String duration
    ) {
        machineService.updateClearTime(duration);
    }

    @GetMapping("/time")
    public TimeDto getTime() {
        return machineService.getTime();
    }

    @GetMapping("/buffer")
    public BufferDto getBuffer() {
        return machineService.getBuffer();
    }

    @Operation(
            summary = "Запуск очистки",
            description = "Запустить удаление всех таймлайнов с заданым окном и интервалом"
    )
    @DeleteMapping("/destroy/all")
    public void destroyAll() {
        destroyServiceApi.allDestroyQueue();
    }
}
