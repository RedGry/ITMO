package ru.tagallteam.template.application.user.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import ru.tagallteam.template.application.role.model.RoleDto;

@Data
public class UserDto {
    @Schema(description = "Ид пользователя", example = "1")
    private Long id;
    @Schema(description = "Логин пользователя", example = "test_login")
    private String login;
    @Schema(description = "Имя пользователя", example = "Юрий")
    private String name;
    @Schema(description = "Роль пользователя")
    private RoleDto role;
}
