package ru.tagallteam.template.error.exception;

import lombok.AllArgsConstructor;
import lombok.Getter;
import ru.tagallteam.template.error.model.ApplicationError;

@Getter
@AllArgsConstructor(staticName = "of")
public class ApplicationException extends RuntimeException {
    private ApplicationError error;
}
