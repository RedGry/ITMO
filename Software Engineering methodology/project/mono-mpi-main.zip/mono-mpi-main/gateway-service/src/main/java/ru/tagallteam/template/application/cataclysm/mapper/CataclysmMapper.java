package ru.tagallteam.template.application.cataclysm.mapper;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;
import ru.tagallteam.template.application.cataclysm.model.CataclysmDto;
import ru.tagallteam.template.application.cataclysm.model.CataclysmTypeDto;
import ru.tagallteam.template.configuration.cataclism.model.CataclysmCreateDto;

@Component
public class CataclysmMapper {
    public CataclysmDto cataclysmDto(ru.tagallteam.template.configuration.cataclism.model.CataclysmDto cataclysmDtoApi) {
        CataclysmDto cataclysmDto = new CataclysmDto();
        cataclysmDto.setId(cataclysmDtoApi.getId());
        cataclysmDto.setPlace(cataclysmDtoApi.getPlace());
        cataclysmDto.setTime(cataclysmDtoApi.getTime());
        cataclysmDto.setDescription(cataclysmDtoApi.getDescription());
        if(ObjectUtils.isNotEmpty(cataclysmDtoApi.getTimeline())){
            cataclysmDto.setResources(cataclysmDtoApi.getTimeline().getResources());
            cataclysmDto.setCostOfResources(cataclysmDtoApi.getTimeline().getCostOfResources());
        }
        if (cataclysmDtoApi.getType() != null) {
            cataclysmDto.setType(cataclysmTypeDto(cataclysmDtoApi.getType()));
        }
        return cataclysmDto;
    }

    public CataclysmTypeDto cataclysmTypeDto(ru.tagallteam.template.configuration.cataclism.model.CataclysmTypeDto cataclysmTypeDtoApi) {
        CataclysmTypeDto cataclysmTypeDto = new CataclysmTypeDto();
        cataclysmTypeDto.setId(cataclysmTypeDtoApi.getId());
        cataclysmTypeDto.setName(cataclysmTypeDtoApi.getName());
        return cataclysmTypeDto;
    }

    public CataclysmCreateDto cataclysmCreateDtoApi(ru.tagallteam.template.application.cataclysm.model.CataclysmCreateDto cataclysmCreateDto) {
        CataclysmCreateDto cataclysmCreateDtoApi = new CataclysmCreateDto();
        cataclysmCreateDtoApi.setPlace(cataclysmCreateDto.getPlace());
        cataclysmCreateDtoApi.setTime(cataclysmCreateDto.getTime());
        cataclysmCreateDtoApi.setDescription(cataclysmCreateDto.getDescription());
        cataclysmCreateDtoApi.setTypeId(cataclysmCreateDto.getTypeId());
        return cataclysmCreateDtoApi;
    }
}
