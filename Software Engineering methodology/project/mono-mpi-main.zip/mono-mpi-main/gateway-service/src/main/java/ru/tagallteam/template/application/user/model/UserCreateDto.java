package ru.tagallteam.template.application.user.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import org.springframework.lang.Nullable;

@Data
public class UserCreateDto {
    @Schema(description = "Логин пользователя", example = "test_login")
    private String login;
    @Schema(description = "Пароль пользователя", example = "123456@#@!@")
    @Nullable
    private String password;
    @Schema(description = "Имя пользователя", example = "Юрий")
    private String name;
    @Schema(description = "Ид роли", example = "1")
    private Long roleId;
}
