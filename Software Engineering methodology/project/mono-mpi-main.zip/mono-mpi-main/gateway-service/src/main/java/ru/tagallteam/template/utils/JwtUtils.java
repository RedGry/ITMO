package ru.tagallteam.template.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import ru.tagallteam.template.configuration.JwtConfig;
import ru.tagallteam.template.configuration.user.model.UserDto;

import java.security.Key;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Base64;
import java.util.Date;

import javax.crypto.spec.SecretKeySpec;

@Component
@RequiredArgsConstructor
public class JwtUtils {
    private final JwtConfig jwtConfig;
    private final ObjectMapper objectMapper;

    public String generateToken(UserDto userDto) {
        try {
            Date now = new Date();
            Date exp = Date.from(LocalDateTime.now().plusHours(jwtConfig.getTimeOfActionAuthToken())
                    .atZone(ZoneId.systemDefault()).toInstant());
            Key hmacKey = new SecretKeySpec(Base64.getDecoder().decode(jwtConfig.getJwtSecret()),
                    SignatureAlgorithm.HS256.getJcaName());
            return Jwts.builder()
                    .setSubject(objectMapper.writeValueAsString(userDto))
                    .setIssuedAt(now)
                    .setNotBefore(now)
                    .setExpiration(exp)
                    .signWith(hmacKey)
                    .compact();
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }


    public boolean validateToken(String token) {
        try {
            Jwts.parser().setSigningKey(jwtConfig.getJwtSecret())
                    .parseClaimsJws(token);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public String getWordForToken(String token) {
        Claims claims = Jwts.parser().setSigningKey(jwtConfig.getJwtSecret())
                .parseClaimsJws(token).getBody();
        return claims.getSubject();
    }

}
