package ru.tagallteam.template.configuration.task.service;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import ru.tagallteam.template.configuration.task.model.TaskCreateDto;
import ru.tagallteam.template.configuration.task.model.TaskDto;
import ru.tagallteam.template.configuration.task.model.UserNotFree;

@FeignClient(name = "task-service", url = "${service.task-service.url}")
public interface TaskServiceApi {
    @PostMapping("/task")
    TaskDto createTask(@RequestBody TaskCreateDto taskCreateDto);

    @PutMapping("/task/{taskId}")
    TaskDto updateTask(@RequestBody TaskCreateDto taskCreateDto, @PathVariable Long taskId);

    @GetMapping("/task/{taskId}")
    TaskDto getTaskById(@PathVariable Long taskId);

    @DeleteMapping("/task/{taskId}")
    void deleteTasks(@PathVariable Long taskId);

    @DeleteMapping("/task/cataclysm/{cataclysmId}")
    void deleteTasksWithCataclysm(@PathVariable Long cataclysmId);

    @GetMapping("/task")
    List<TaskDto> getTasks(@RequestParam Long page, @RequestParam Long limit);

    @GetMapping("/task/user/not/free")
    UserNotFree getUserNotFree();

    @PutMapping("/task/{taskId}/set/executor/{executorId}")
    TaskDto setTaskExecutor(@PathVariable Long taskId, @PathVariable Long executorId);

    @PutMapping("/task/{taskId}/start")
    TaskDto startTask(@PathVariable Long taskId);

    @PutMapping("/task/{taskId}/completed")
    TaskDto completedTask(@PathVariable Long taskId);

    @PutMapping("/task/{taskId}/timeline/{timelineId}/collect")
    TaskDto collectResources(@PathVariable Long taskId, @PathVariable Long timelineId);
}
