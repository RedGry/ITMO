package ru.tagallteam.template.configuration.user.model;

import jakarta.annotation.Nullable;
import lombok.Data;

@Data
public class UserCreateDto {
    private String name;
    private String login;
    @Nullable
    private String password;
    private Long roleId;
}
