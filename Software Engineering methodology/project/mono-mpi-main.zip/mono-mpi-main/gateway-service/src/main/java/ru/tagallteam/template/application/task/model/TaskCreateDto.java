package ru.tagallteam.template.application.task.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class TaskCreateDto {
    @Schema(description = "Описание задания", example = "Тестовое описание")
    private String description;
    @Schema(description = "Ид пользователя", example = "1")
    private Long executorId;
    @Schema(description = "Ид катаклизма", example = "1")
    private Long cataclysmId;
}
