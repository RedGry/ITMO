package ru.tagallteam.template.application.task.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import ru.tagallteam.template.application.cataclysm.model.CataclysmDto;
import ru.tagallteam.template.application.user.model.UserDto;

@Data
public class TaskDto {
    @Schema(description = "Ид задания", example = "1")
    private Long id;
    @Schema(description = "Описание задания", example = "Тестовое описание")
    private String description;
    @Schema(description = "Пользователь - исполнитель")
    private UserDto executor;
    @Schema(description = "Катаклизм")
    private CataclysmDto cataclysm;
    @Schema(description = "Статус выполнения задания")
    private TaskStatusDto status;
}
