package ru.tagallteam.template.application.auth.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class AuthDto {
    @Schema(description = "Логин пользователя", example = "test")
    private String login;
    @Schema(description = "Пароль пользователя", example = "!123456789!")
    private String pass;
}
