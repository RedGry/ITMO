package ru.tagallteam.template.configuration.cataclism.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;
import ru.tagallteam.template.application.common.Constants;

import java.time.LocalDateTime;
import java.util.List;

@Data
public class TimelineDto {
    private Long id;
    private Long parentId;
    private Boolean common;
    private Boolean connected;
    private Boolean destroyed;
    private Boolean robbery;
    private List<ResourceDto> resources;
    private Long costOfResources;
    @JsonFormat(pattern = Constants.DATE_TIME_FORMAT)
    private LocalDateTime createTime;
}
