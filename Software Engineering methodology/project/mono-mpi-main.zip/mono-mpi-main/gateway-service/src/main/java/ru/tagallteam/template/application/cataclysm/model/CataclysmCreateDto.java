package ru.tagallteam.template.application.cataclysm.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import ru.tagallteam.template.application.common.Constants;

import java.time.LocalTime;

@Data
public class CataclysmCreateDto {
    @Schema(description = "Название места", example = "Санкт-Петербург")
    private String place;
    @Schema(description = "Время возникновения катаклизма", example = "12:30:23")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = Constants.TIME_FORMAT)
    private LocalTime time;
    @Schema(description = "Описание катаклизма", example = "Описание катаклизма")
    private String description;
    @Schema(description = "Ид типа катаклизма", example = "1")
    private Long typeId;
}
