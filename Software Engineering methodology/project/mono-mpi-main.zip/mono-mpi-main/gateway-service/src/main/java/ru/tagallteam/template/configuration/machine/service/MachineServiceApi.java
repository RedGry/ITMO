package ru.tagallteam.template.configuration.machine.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import ru.tagallteam.template.configuration.machine.model.BufferDto;
import ru.tagallteam.template.configuration.machine.model.TimeDto;

@FeignClient(name = "machine-service", url = "${service.machine-service.url}")
public interface MachineServiceApi {
    @PutMapping("/machine/clear/time")
    void clearTime(@RequestParam String time);

    @PutMapping("/machine/buffer/size")
    void setBufferSize(@RequestParam Long bufferSize);

    @GetMapping("/machine/time")
    TimeDto getTime();

    @GetMapping("/machine/buffer")
    BufferDto getBuffer();
}
