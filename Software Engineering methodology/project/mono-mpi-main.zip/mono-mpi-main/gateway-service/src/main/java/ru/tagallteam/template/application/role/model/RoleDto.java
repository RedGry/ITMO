package ru.tagallteam.template.application.role.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class RoleDto {
    @Schema(description = "Ид роли", example = "1")
    private Long id;
    @Schema(description = "Имя роли", example = "Администратор")
    private String name;
}
