package ru.tagallteam.template.configuration.auth.model;

import lombok.Data;

@Data
public class Status {
    boolean login;
}
