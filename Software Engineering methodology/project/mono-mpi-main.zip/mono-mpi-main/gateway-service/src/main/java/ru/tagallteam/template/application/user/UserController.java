package ru.tagallteam.template.application.user;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.tagallteam.template.application.user.model.PasswordDto;
import ru.tagallteam.template.application.user.model.UserCreateDto;
import ru.tagallteam.template.application.user.model.UserDto;
import ru.tagallteam.template.application.user.service.UserService;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/user")
public class UserController {

    private final UserService userService;

    @Operation(
            summary = "Получение пользователей",
            description = "Позволяет получить пользователей постранично с указанием кол. элементов на странице"
    )
    @GetMapping("")
    public List<UserDto> getUsers(
            @Parameter(description = "Номер страници", example = "0")
            @RequestParam Long page,
            @Parameter(description = "Количество элементов на странице", example = "10")
            @RequestParam Long limit
    ) {
        return userService.getUsers(page, limit);
    }

    @Operation(
            summary = "Получение пользователя",
            description = "Позволяет получить пользователя по ид"
    )
    @GetMapping("/{userId}")
    public UserDto getUser(
            @Parameter(description = "Ид пользователя", example = "1")
            @PathVariable Long userId
    ) {
        return userService.getUser(userId);
    }

    @Operation(
            summary = "Создание пользователя",
            description = "Позволяет создать пользователя"
    )
    @PostMapping("")
    public UserDto createUser(@RequestBody UserCreateDto userUpdateDto) {
        return userService.create(userUpdateDto);
    }

    @Operation(
            summary = "Обновление пользователя",
            description = "Позволяет обновить пользователя"
    )
    @PutMapping("/{userId}")
    public UserDto updateUser(@RequestBody UserCreateDto userUpdateDto,
                              @Parameter(description = "Ид пользователя", example = "1")
                              @PathVariable Long userId
    ) {
        return userService.updateUser(userId, userUpdateDto);
    }

    @Operation(
            summary = "Генериция пароля для пользователя",
            description = "Позволяет сгенерировать новый пароль для пользователя или обновить старый пароль"
    )
    @PutMapping("/{userId}/generate/password")
    public PasswordDto generatePassword(
            @Parameter(description = "Ид пользователя", example = "1")
            @PathVariable Long userId
    ) {
        return userService.generatePassword(userId);
    }

    @GetMapping("/free")
    public List<UserDto> getFreeUsers() {
        return userService.getFreeUsers();
    }

}
