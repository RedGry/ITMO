package ru.tagallteam.template.configuration.machine.configuration;

import com.fasterxml.jackson.databind.ObjectMapper;
import feign.codec.ErrorDecoder;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.DefaultUriBuilderFactory;
import ru.tagallteam.template.configuration.machine.service.DestroyServiceApi;
import ru.tagallteam.template.configuration.machine.service.MachineServiceApi;
import ru.tagallteam.template.utils.FeignUtil;

@Configuration
@RequiredArgsConstructor
public class MachineConfiguration {
    private final ErrorDecoder errorDecoder;

    private final ObjectMapper objectMapper;

    private final MachineConfigurationProperties properties;

    /**
     * Шаблон обслуживания.
     *
     * @return {@link RestTemplate}.
     */
    @Bean
    @Qualifier("MachineServiceRestTemplate")
    @ConditionalOnMissingBean(name = "MachineServiceRestTemplate")
    public RestTemplate machineServiceRestTemplate() {
        SimpleClientHttpRequestFactory clientHttpRequestFactory = new SimpleClientHttpRequestFactory();
        clientHttpRequestFactory.setConnectTimeout(properties.getTimout());
        clientHttpRequestFactory.setReadTimeout(properties.getTimout());
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.setUriTemplateHandler(new DefaultUriBuilderFactory(properties.getUrl()));
        restTemplate.getMessageConverters().stream()
                .filter(it -> it instanceof MappingJackson2HttpMessageConverter)
                .map(it -> (MappingJackson2HttpMessageConverter) it)
                .forEach(it -> it.setObjectMapper(objectMapper));
        return restTemplate;
    }

    @Bean
    public MachineServiceApi machineServiceApi(ObjectFactory<HttpMessageConverters> messageConverters) {
        return FeignUtil.buildFeignClient(MachineServiceApi.class, properties.getUrl(), messageConverters, errorDecoder);
    }

    @Bean
    public DestroyServiceApi destroyServiceApi(ObjectFactory<HttpMessageConverters> messageConverters) {
        return FeignUtil.buildFeignClient(DestroyServiceApi.class, properties.getUrl(), messageConverters, errorDecoder);
    }
}
