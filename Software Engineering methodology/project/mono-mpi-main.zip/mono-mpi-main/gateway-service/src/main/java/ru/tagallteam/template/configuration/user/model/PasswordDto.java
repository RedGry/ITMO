package ru.tagallteam.template.configuration.user.model;

import lombok.Data;

@Data
public class PasswordDto {
    String password;
}
