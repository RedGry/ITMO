package ru.tagallteam.template.application.role;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import ru.tagallteam.template.application.role.mapper.RoleMapper;
import ru.tagallteam.template.application.role.model.RoleDto;
import ru.tagallteam.template.configuration.user.service.RoleServiceApi;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/role")
public class RoleController {

    private final RoleServiceApi roleServiceApi;
    private final RoleMapper roleMapper;

    @Operation(
            summary = "Получение все роли",
            description = "Позволяет получить все роли"
    )
    @GetMapping()
    public List<RoleDto> getRoles() {
        return roleServiceApi.getRoles().stream().map(roleMapper::toDto).toList();
    }

    @Operation(
            summary = "Получение роли",
            description = "Позволяет получить роль по ид"
    )
    @GetMapping("/{roleId}")
    public RoleDto getRole(@Parameter(description = "Ид роли", example = "1") @PathVariable Long roleId) {
        return roleMapper.toDto(roleServiceApi.getRole(roleId));
    }

}
