package ru.tagallteam.template.application.auth.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import ru.tagallteam.template.application.user.model.UserDto;

@Data
public class TokenDto {
    @Schema(description = "Токен доступа для обновления токена авторизации")
    private String accessToken;
    @Schema(description = "Токен авторизации")
    private String authToken;
    private UserDto userDto;
}
