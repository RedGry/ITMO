package ru.tagallteam.template.application.cataclysm.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.tagallteam.template.application.cataclysm.mapper.CataclysmMapper;
import ru.tagallteam.template.application.cataclysm.model.CataclysmCreateDto;
import ru.tagallteam.template.application.cataclysm.model.CataclysmDto;
import ru.tagallteam.template.application.task.service.TaskService;
import ru.tagallteam.template.configuration.cataclism.service.CataclysmServiceApi;
import ru.tagallteam.template.configuration.task.service.TaskServiceApi;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CataclysmService {

    private final CataclysmServiceApi cataclysmServiceApi;

    private final CataclysmMapper cataclysmMapper;

    private final TaskServiceApi taskServiceApi;

    public CataclysmDto createCataclysm(CataclysmCreateDto cataclysmCreateDto) {
        return cataclysmMapper.cataclysmDto(cataclysmServiceApi.createCataclysm(
                cataclysmMapper.cataclysmCreateDtoApi(cataclysmCreateDto))
        );
    }

    public List<CataclysmDto> getCataclysms(Long page, Long limit) {
        return cataclysmServiceApi.getCataclysms(page, limit).stream().map(cataclysmMapper::cataclysmDto).toList();
    }


    public CataclysmDto getCataclysm(Long cataclysmId) {
        return cataclysmMapper.cataclysmDto(cataclysmServiceApi.getCataclysm(cataclysmId));
    }


    public CataclysmDto updateCataclysm(Long cataclysmId, CataclysmCreateDto cataclysmCreateDto) {
        return cataclysmMapper.cataclysmDto(cataclysmServiceApi.updateCataclysm(
                cataclysmId,
                cataclysmMapper.cataclysmCreateDtoApi(cataclysmCreateDto)
        ));
    }


    public void deleteCataclysm(Long cataclysmId) {
        cataclysmServiceApi.deleteCataclysm(cataclysmId);
        taskServiceApi.deleteTasksWithCataclysm(cataclysmId);
    }
}
