package ru.tagallteam.template.application.role.mapper;

import org.springframework.stereotype.Component;
import ru.tagallteam.template.application.role.model.RoleDto;

@Component
public class RoleMapper {
    public RoleDto toDto(ru.tagallteam.template.configuration.user.model.RoleDto roleDtoApi){
        RoleDto roleDto = new RoleDto();
        roleDto.setId(roleDtoApi.getId());
        roleDto.setName(roleDtoApi.getName());
        return roleDto;
    }
}
