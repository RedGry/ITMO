package ru.tagallteam.template.configuration.task.model;

import lombok.Data;

@Data
public class StatusDto {
    private Long id;
    private String name;
}
