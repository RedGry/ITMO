package ru.tagallteam.template.configuration.auth.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import ru.tagallteam.template.configuration.auth.model.AuthDto;
import ru.tagallteam.template.configuration.auth.model.Status;

@FeignClient(name = "auth-service", url = "${service.auth-service.url}")
public interface AuthServiceApi {
    @PostMapping("/auth/login/{userId}")
    AuthDto login(@RequestBody AuthDto authDto, @PathVariable Long userId);

    @DeleteMapping("/auth/logout")
    void logout(@RequestBody AuthDto authDto);

    @PostMapping("/auth/is-login")
    Status isLogin(@RequestBody AuthDto authDto);
}
