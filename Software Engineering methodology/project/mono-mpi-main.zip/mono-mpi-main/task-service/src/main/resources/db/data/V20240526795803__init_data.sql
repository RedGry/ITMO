insert into status (id, name)
values (nextval('status_seq'), 'Создана'),
       (nextval('status_seq'), 'Назначена'),
       (nextval('status_seq'), 'В работе'),
       (nextval('status_seq'), 'Успешно завершено'),
       (nextval('status_seq'), 'Timeline разрушен'),
       (nextval('status_seq'), 'Timeline ограблен');
