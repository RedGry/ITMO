create sequence status_seq;

create table status
(
    id   int primary key,
    name varchar(256)
);

create sequence task_seq;

create table task
(
    id           int primary key,
    status_id    int references status (id),
    executor_id  int,
    cataclysm_id int not null unique,
    description  text
);

create sequence collect_resource_task_seq;

create table collect_resource_task
(
    id             int primary key,
    task_id        int references task (id),
    timeline_id    int not null,
    resource_id    int not null,
    resource_count int not null
);