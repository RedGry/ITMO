package ru.tagallteam.task.application.task.service;

import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.stream.Collectors;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;
import ru.tagallteam.task.application.task.domain.CollectResourceTaskRepository;
import ru.tagallteam.task.application.task.domain.StatusRepository;
import ru.tagallteam.task.application.task.domain.Task;
import ru.tagallteam.task.application.task.domain.TaskRepository;
import ru.tagallteam.task.application.task.mapper.TaskMapper;
import ru.tagallteam.task.application.task.model.TaskCreateDto;
import ru.tagallteam.task.application.task.model.TaskDto;
import ru.tagallteam.task.application.task.model.UserNotFree;
import ru.tagallteam.task.configuration.timeline.model.TimelineDto;
import ru.tagallteam.task.configuration.timeline.service.TimelineService;
import ru.tagallteam.task.error.ErrorDescriptor;

import static ru.tagallteam.task.error.ErrorDescriptor.TASK_IS_ASSIGN;
import static ru.tagallteam.task.error.ErrorDescriptor.TASK_STATUS_BED;

@Service
@RequiredArgsConstructor
public class TaskService {

    private final TaskRepository taskRepository;

    private final StatusRepository statusRepository;

    private final TaskMapper taskMapper;

    private final TimelineService timelineService;

    private final CollectResourceTaskRepository collectResourceTaskRepository;

    public TaskDto createTask(TaskCreateDto taskCreateDto) {
        TASK_IS_ASSIGN.throwIsTrue(taskRepository.existsByCataclysmId(taskCreateDto.getCataclysmId()));
        return taskMapper.toDto(taskRepository.save(taskMapper.toEntity(taskCreateDto)));
    }

    public TaskDto updateTask(TaskCreateDto taskCreateDto, Long taskId) {
        ErrorDescriptor.TASK_NOT_FOUNT.throwIsFalse(taskRepository.existsById(taskId));
        TASK_STATUS_BED.throwIsTrue(taskRepository.getReferenceById(taskId).getStatus().getId() > 3);
        return taskMapper.toDto(taskRepository.save(taskMapper.toEntity(taskId, taskCreateDto)));
    }

    public void deleteTasks(Long taskId) {
        ErrorDescriptor.TASK_NOT_FOUNT.throwIsFalse(taskRepository.existsById(taskId));
        taskRepository.deleteById(taskId);
    }

    public void deleteTasksWithCataclysm(Long cataclysmId) {
        taskRepository.deleteAllByCataclysmId(cataclysmId);
    }

    public TaskDto getTaskById(Long taskId) {
        ErrorDescriptor.TASK_NOT_FOUNT.throwIsFalse(taskRepository.existsById(taskId));
        return taskMapper.toDto(taskRepository.getReferenceById(taskId));
    }

    public List<TaskDto> getTasks(Long page, Long limit) {
        Pageable pageable = PageRequest.of(
                ObjectUtils.isEmpty(page) ? 0 : page.intValue(),
                ObjectUtils.isEmpty(limit) ? 10 : limit.intValue()
        );
        return taskRepository.findAll(pageable).map(taskMapper::toDto).toList();
    }

    /**
     *
     * @return пользователи которые заняты.
     */
    public UserNotFree getUserNotFree() {
        UserNotFree userNotFree = new UserNotFree();
        Map<Long, Long> executorTaskCount = taskRepository.findAll().stream()
                .collect(Collectors.groupingBy(Task::getExecutorId, Collectors.counting()));
        userNotFree.setUserIds(executorTaskCount.entrySet().stream()
                .filter(entry -> entry.getValue() > 3)
                .map(Map.Entry::getKey)
                .toList()
        );
        return userNotFree;
    }

    public TaskDto setTaskExecutor(Long taskId, Long executorId) {
        ErrorDescriptor.TASK_NOT_FOUNT.throwIsFalse(taskRepository.existsById(taskId));
        ErrorDescriptor.USER_HASE_THREE_TASK.throwIsTrue(taskRepository.countByExecutorId(executorId) > 3);
        Task task = taskRepository.getReferenceById(taskId);
        task.setExecutorId(executorId);
        task.setStatus(statusRepository.getReferenceById(2L));
        return taskMapper.toDto(taskRepository.save(task));
    }

    public TaskDto startTask(Long taskId) {
        ErrorDescriptor.TASK_NOT_FOUNT.throwIsFalse(taskRepository.existsById(taskId));
        Task task = taskRepository.getReferenceById(taskId);
        task.setStatus(statusRepository.getReferenceById(3L));
        return taskMapper.toDto(taskRepository.save(task));
    }

    public TaskDto completedTask(Long taskId) {
        ErrorDescriptor.TASK_NOT_FOUNT.throwIsFalse(taskRepository.existsById(taskId));
        Task task = taskRepository.getReferenceById(taskId);
        TASK_STATUS_BED.throwIsFalse(task.getStatus().getId().equals(3L));
        if (randInt(1, 100) >= 40) {
            task.setStatus(statusRepository.getReferenceById(4L));
        } else {
            task.setStatus(statusRepository.getReferenceById(5L));
        }
        return taskMapper.toDto(taskRepository.save(task));
    }

    @Transactional
    public TaskDto collectResources(Long taskId, Long timelineId) {
        ErrorDescriptor.TASK_NOT_FOUNT.throwIsFalse(taskRepository.existsById(taskId));
        Task task = taskRepository.getReferenceById(taskId);
        ErrorDescriptor.TASK_NOT_DESTROY.throwIsFalse(task.getStatus().getId().equals(5L));
        TimelineDto timelineDto = timelineService.robbery(timelineId);
        if (timelineDto.getRobbery()) {
            timelineDto.getResources().forEach(resourceDto -> {
                collectResourceTaskRepository.save(
                        taskMapper.collectResourceTask(task, timelineId, resourceDto.getId(), resourceDto.getCount())
                );
            });
            task.setStatus(statusRepository.getReferenceById(6L));
        }
        return taskMapper.toDto(taskRepository.save(task));
    }

    private static int randInt(int min, int max) {
        return new Random().nextInt((max - min) + 1) + min;
    }
}
