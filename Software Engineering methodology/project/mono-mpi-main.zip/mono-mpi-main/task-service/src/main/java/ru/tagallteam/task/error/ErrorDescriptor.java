package ru.tagallteam.task.error;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.util.ObjectUtils;
import ru.tagallteam.task.error.exception.ApplicationException;
import ru.tagallteam.task.error.model.ApplicationError;

@Getter
@AllArgsConstructor
public enum ErrorDescriptor {
    TASK_IS_ASSIGN("Задача уже назначена", HttpStatus.BAD_REQUEST),
    TASK_NOT_FOUNT("Задача не найдена", HttpStatus.NOT_FOUND),
    TASK_STATUS_BED("Задача находиться в не корректном статусе", HttpStatus.BAD_REQUEST),
    TASK_NOT_DESTROY("Задача не привела к уничтождению timeline, невозможно ограбить timeline", HttpStatus.BAD_REQUEST),
    USER_HASE_THREE_TASK("У пользователя уже есть 3 задачи, выберите другого", HttpStatus.BAD_REQUEST),
    NOT_FOUND_TIMELINE("Такого timeline не существует", HttpStatus.NOT_FOUND),
    DATA_BASE_ERROR("Ошибка взаимодействия с бд", HttpStatus.BAD_REQUEST),
    INTERNAL_SERVER_ERROR("Неожиданная ошибка сервиса", HttpStatus.INTERNAL_SERVER_ERROR),
    NOT_FOUND("Запрошенный ресурс (интерфейс) не существует", HttpStatus.NOT_FOUND);


    private final String message;


    private final HttpStatus status;

    public void exception() {
        throw ApplicationException.of(applicationError());
    }

    public ApplicationException callExceptionModel() {
        return ApplicationException.of(applicationError());
    }

    public void throwIsTrue(Boolean flag) {
        if (flag) {
            exception();
        }
    }

    public void throwIsFalse(Boolean flag) {
        if (!flag) {
            exception();
        }
    }

    public void throwIsNull(Object object) {
        if (ObjectUtils.isEmpty(object)) {
            exception();
        }
    }

    public ApplicationError applicationError() {
        return new ApplicationError(this.message, this.status);
    }

}
