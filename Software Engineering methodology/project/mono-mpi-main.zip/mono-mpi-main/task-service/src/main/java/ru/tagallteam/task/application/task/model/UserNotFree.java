package ru.tagallteam.task.application.task.model;

import lombok.Data;

import java.util.List;

@Data
public class UserNotFree {
    List<Long> userIds;
}
