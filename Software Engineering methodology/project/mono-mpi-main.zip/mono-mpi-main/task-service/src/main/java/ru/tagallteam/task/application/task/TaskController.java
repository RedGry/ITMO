package ru.tagallteam.task.application.task;

import java.util.List;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.tagallteam.task.application.task.model.TaskCreateDto;
import ru.tagallteam.task.application.task.model.TaskDto;
import ru.tagallteam.task.application.task.model.UserNotFree;
import ru.tagallteam.task.application.task.service.TaskService;

@RestController
@AllArgsConstructor
@RequestMapping("/v1/task")
public class TaskController {

    private final TaskService taskService;

    @PostMapping
    public TaskDto createTask(@RequestBody TaskCreateDto taskCreateDto) {
        return taskService.createTask(taskCreateDto);
    }

    @PutMapping("/{taskId}")
    public TaskDto updateTask(@RequestBody TaskCreateDto taskCreateDto, @PathVariable Long taskId) {
        return taskService.updateTask(taskCreateDto, taskId);
    }

    @DeleteMapping("/{taskId}")
    public void deleteTasks(@PathVariable Long taskId) {
        taskService.deleteTasks(taskId);
    }

    @DeleteMapping("/cataclysm/{cataclysmId}")
    public void deleteTasksWithCataclysm(@PathVariable Long cataclysmId) {
        taskService.deleteTasksWithCataclysm(cataclysmId);
    }

    @GetMapping("/{taskId}")
    public TaskDto getTaskById(@PathVariable Long taskId) {
        return taskService.getTaskById(taskId);
    }

    @GetMapping
    public List<TaskDto> getTasks(@RequestParam Long page, @RequestParam Long limit) {
        return taskService.getTasks(page, limit);
    }

    @GetMapping("/user/not/free")
    public UserNotFree getUserNotFree() {
        return taskService.getUserNotFree();
    }

    @PutMapping("/{taskId}/set/executor/{executorId}")
    public TaskDto setTaskExecutor(@PathVariable Long taskId, @PathVariable Long executorId) {
        return taskService.setTaskExecutor(taskId, executorId);
    }

    @PutMapping("/{taskId}/start")
    public TaskDto startTask(@PathVariable Long taskId) {
        return taskService.startTask(taskId);
    }

    @PutMapping("/{taskId}/completed")
    public TaskDto completedTask(@PathVariable Long taskId) {
        return taskService.completedTask(taskId);
    }

    @PutMapping("/{taskId}/timeline/{timelineId}/collect")
    public TaskDto collectResources(@PathVariable Long taskId, @PathVariable Long timelineId) {
        return taskService.collectResources(taskId, timelineId);
    }
}
