package ru.tagallteam.task.application.task.model;

import lombok.Data;

@Data
public class StatusDto {
    private Long id;
    private String name;
}
