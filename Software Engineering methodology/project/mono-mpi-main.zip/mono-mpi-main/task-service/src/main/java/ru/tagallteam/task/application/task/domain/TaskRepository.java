package ru.tagallteam.task.application.task.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TaskRepository extends JpaRepository<Task, Long> {
    Long countByExecutorId(Long executorId);
    boolean existsByCataclysmId(Long cataclysmId);

    void deleteAllByCataclysmId(Long cataclysmId);
}
