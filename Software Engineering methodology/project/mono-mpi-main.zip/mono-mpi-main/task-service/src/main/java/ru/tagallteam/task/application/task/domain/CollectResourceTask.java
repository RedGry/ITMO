package ru.tagallteam.task.application.task.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Entity
@ToString(of = "id")
@Table(name = "collect_resource_task")
public class CollectResourceTask {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence")
    @SequenceGenerator(name = "sequence", allocationSize = 1, sequenceName = "collect_resource_task_seq")
    private Long id;
    @ManyToOne
    @JoinColumn(name = "task_id")
    private Task task;
    @Column(name = "timeline_id")
    private Long timelineId;
    @Column(name = "resource_id")
    private Long resourceId;
    @Column(name = "resource_count")
    private Long count;
}
