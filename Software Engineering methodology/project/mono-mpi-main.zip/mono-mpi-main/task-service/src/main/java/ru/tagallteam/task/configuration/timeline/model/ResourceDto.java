package ru.tagallteam.task.configuration.timeline.model;

import lombok.Data;

@Data
public class ResourceDto {
    private Long id;
    private String name;
    private Long count;
}
