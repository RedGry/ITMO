package ru.tagallteam.task.error.decoder;

import com.fasterxml.jackson.databind.ObjectMapper;
import feign.Response;
import feign.codec.ErrorDecoder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.http.HttpStatus;
import ru.tagallteam.task.error.exception.ApplicationException;
import ru.tagallteam.task.error.model.ApplicationError;

import java.io.IOException;

@Slf4j
@RequiredArgsConstructor
public class CustomErrorDecoder implements ErrorDecoder {

    /**
     * {@inheritDoc}.
     */
    private final ObjectMapper objectMapper;

    @Override
    public Exception decode(String methodKey, Response response) {
        String body;
        try {
            body = IOUtils.toString(response.body().asInputStream());
        } catch (IOException ioe) {
            body = "";
        }

        ApplicationError error;
        try {
            error = objectMapper.readValue(body, ApplicationError.class);
        } catch (Exception e) {
            log.error("the error occurred while decoding response body", e);
            error = new ApplicationError("Неизвестная ошибка сервера", HttpStatus.BAD_REQUEST);
        }
        return ApplicationException.of(error);
    }

}
