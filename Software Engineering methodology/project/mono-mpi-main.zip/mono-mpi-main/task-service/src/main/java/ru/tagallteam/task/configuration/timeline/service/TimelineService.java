package ru.tagallteam.task.configuration.timeline.service;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import ru.tagallteam.task.configuration.timeline.model.TimelineDto;

@FeignClient(name = "timeline-service", url = "${service.timeline-service.url}")
public interface TimelineService {
    @PutMapping("/timeline/{timelineId}/robbery")
    TimelineDto robbery(@PathVariable Long timelineId);
}
