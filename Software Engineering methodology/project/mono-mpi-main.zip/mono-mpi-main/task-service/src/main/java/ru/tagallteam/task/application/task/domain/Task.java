package ru.tagallteam.task.application.task.domain;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

@Getter
@Setter
@Entity
@ToString(of = "id")
@Table(name = "task")
public class Task {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence")
    @SequenceGenerator(name = "sequence", allocationSize = 1, sequenceName = "task_seq")
    private Long id;
    @ManyToOne
    @JoinColumn(name = "status_id")
    private Status status;
    @Column(name = "executor_id")
    private Long executorId;
    @Column(name = "cataclysm_id")
    private Long cataclysmId;
    private String description;

    @OneToMany(mappedBy = "task", cascade = CascadeType.ALL)
    private List<CollectResourceTask> collectResources;
}
