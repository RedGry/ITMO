package ru.tagallteam.task.application.task.mapper;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import ru.tagallteam.task.application.task.domain.CollectResourceTask;
import ru.tagallteam.task.application.task.domain.Status;
import ru.tagallteam.task.application.task.domain.StatusRepository;
import ru.tagallteam.task.application.task.domain.Task;
import ru.tagallteam.task.application.task.model.StatusDto;
import ru.tagallteam.task.application.task.model.TaskCreateDto;
import ru.tagallteam.task.application.task.model.TaskDto;

@Component
@RequiredArgsConstructor
public class TaskMapper {

    private final StatusRepository statusRepository;

    public Task toEntity(TaskCreateDto taskCreateDto) {
        Task task = new Task();
        task.setDescription(taskCreateDto.getDescription());
        task.setCataclysmId(taskCreateDto.getCataclysmId());
        if (ObjectUtils.isEmpty(taskCreateDto.getExecutorId())) {
            task.setStatus(statusRepository.getReferenceById(1L));
        } else {
            task.setExecutorId(taskCreateDto.getExecutorId());
            task.setStatus(statusRepository.getReferenceById(2L));
        }
        return task;
    }

    public Task toEntity(Long taskId, TaskCreateDto taskCreateDto) {
        Task task = new Task();
        task.setId(taskId);
        task.setDescription(taskCreateDto.getDescription());
        task.setCataclysmId(taskCreateDto.getCataclysmId());
        if (ObjectUtils.isEmpty(taskCreateDto.getExecutorId())) {
            task.setStatus(statusRepository.getReferenceById(1L));
        } else {
            task.setExecutorId(taskCreateDto.getExecutorId());
            task.setStatus(statusRepository.getReferenceById(2L));
        }
        return task;
    }

    public TaskDto toDto(Task task) {
        TaskDto taskDto = new TaskDto();
        taskDto.setId(task.getId());
        taskDto.setDescription(task.getDescription());
        taskDto.setCataclysmId(task.getCataclysmId());
        taskDto.setExecutorId(task.getExecutorId());
        taskDto.setStatusDto(toDto(task.getStatus()));
        return taskDto;
    }

    public CollectResourceTask collectResourceTask(Task task, Long timeLineId, Long resourceId, Long count) {
        CollectResourceTask collectResourceTask = new CollectResourceTask();
        collectResourceTask.setTask(task);
        collectResourceTask.setTimelineId(timeLineId);
        collectResourceTask.setResourceId(resourceId);
        collectResourceTask.setCount(count);
        return collectResourceTask;
    }

    private StatusDto toDto(Status status) {
        StatusDto statusDto = new StatusDto();
        statusDto.setId(status.getId());
        statusDto.setName(status.getName());
        return statusDto;
    }
}
