package ru.tagallteam.task.application.task.model;

import lombok.Data;

@Data
public class TaskCreateDto {
    private Long executorId;
    private Long cataclysmId;
    private String description;
}
