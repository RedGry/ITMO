package ru.tagallteam.timeline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

class TimelineServiceApplicationTests {

}
