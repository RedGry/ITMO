create sequence timeline_seq;

create table timeline
(
    id          int primary key,
    parent_id   int references timeline (id),
    common      boolean   not null default false,
    connected   boolean   not null default false,
    destroyed   boolean   not null default false,
    robbery     boolean   not null default false,
    create_time timestamp not null default now()
);

create sequence resource_seq;

create table resource
(
    id   int primary key,
    name varchar(256) not null,
    cost int          not null
);

create table timeline_resource
(
    timeline_id int not null references timeline (id),
    resource_id int not null references resource (id),
    count       int not null default 0,
    unique (timeline_id, resource_id)
);