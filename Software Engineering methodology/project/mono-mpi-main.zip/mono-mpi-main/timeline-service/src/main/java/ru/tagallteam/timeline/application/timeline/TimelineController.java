package ru.tagallteam.timeline.application.timeline;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.*;
import ru.tagallteam.timeline.application.timeline.model.ConnectedDto;
import ru.tagallteam.timeline.application.timeline.model.DestroyTimelineDto;
import ru.tagallteam.timeline.application.timeline.model.RandomTimeline;
import ru.tagallteam.timeline.application.timeline.model.TimelineDto;
import ru.tagallteam.timeline.application.timeline.service.TimelineService;

import java.util.List;

@RestController
@RequestMapping("/v1/timeline")
@AllArgsConstructor
public class TimelineController {

    private final TimelineService timelineService;

    @PostMapping("")
    public TimelineDto createTimeline(@RequestBody Long parentTimelineId) {
        return timelineService.createTimeline(parentTimelineId);
    }

    @PostMapping("/random")
    public TimelineDto createRandomTimeline() {
        return timelineService.createRandomTimeline();
    }

    @GetMapping("/{timelineId}")
    public TimelineDto getTimeline(@PathVariable Long timelineId) {
        return timelineService.getTimeline(timelineId);
    }

    @DeleteMapping("/{timelineId}")
    public DestroyTimelineDto destroyTimeline(@PathVariable Long timelineId) {
        return timelineService.destroyTimeline(timelineId);
    }

    @PutMapping("/connected/{connectedCount}")
    public ConnectedDto connected(@PathVariable Long connectedCount) {
        return timelineService.connected(connectedCount);
    }

    @PutMapping("/{timelineId}/robbery")
    public TimelineDto robbery(@PathVariable Long timelineId) {
        return timelineService.robbery(timelineId);
    }

    @GetMapping("/random")
    public RandomTimeline getRandomTimeline() {
        return timelineService.getRandomTimeline();
    }

    @GetMapping("/all")
    public List<Long> getAllTimelineIds() {
        return timelineService.getAllTimelineIds();
    }
}
