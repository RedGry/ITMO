package ru.tagallteam.timeline.application.timeline.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Embeddable
@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "of")
public class TimelineResourcePk implements Serializable {
    @Column(name = "timeline_id")
    private Long timelineId;
    @Column(name = "resource_id")
    private Long resourceId;
}
