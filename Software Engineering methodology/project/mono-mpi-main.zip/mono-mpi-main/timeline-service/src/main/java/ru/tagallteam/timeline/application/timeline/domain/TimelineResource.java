package ru.tagallteam.timeline.application.timeline.domain;


import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Entity
@Table(name = "timeline_resource")
@NoArgsConstructor
public class TimelineResource {
    @EmbeddedId
    private TimelineResourcePk timelineResourcePk;
    private Long count;
}
