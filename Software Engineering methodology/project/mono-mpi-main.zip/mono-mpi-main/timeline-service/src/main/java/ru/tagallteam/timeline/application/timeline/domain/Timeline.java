package ru.tagallteam.timeline.application.timeline.domain;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.SequenceGenerator;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.time.LocalDateTime;
import java.util.List;


@Getter
@Setter
@Entity
@ToString(of = "id")
@Table(name = "timeline")
public class Timeline {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequence")
    @SequenceGenerator(name = "sequence", allocationSize = 1, sequenceName = "timeline_seq")
    private Long id;
    @ManyToOne
    @JoinColumn(name = "parent_id")
    private Timeline timeline;
    private Boolean common = false;
    private Boolean connected = false;
    private Boolean destroyed = false;
    private Boolean robbery = false;
    @Column(name = "create_time")
    private LocalDateTime createTime = LocalDateTime.now();
    @OneToMany(mappedBy = "timeline", cascade = CascadeType.ALL)
    private List<Timeline> childrenTimelines;
}
