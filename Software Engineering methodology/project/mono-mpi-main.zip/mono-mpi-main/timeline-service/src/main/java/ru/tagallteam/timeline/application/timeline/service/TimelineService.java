package ru.tagallteam.timeline.application.timeline.service;

import jakarta.transaction.Transactional;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import ru.tagallteam.timeline.application.timeline.domain.Timeline;
import ru.tagallteam.timeline.application.timeline.domain.TimelineRepository;
import ru.tagallteam.timeline.application.timeline.domain.TimelineResourceRepository;
import ru.tagallteam.timeline.application.timeline.mapper.TimelineMapper;
import ru.tagallteam.timeline.application.timeline.model.*;
import ru.tagallteam.timeline.error.ErrorDescriptor;

import java.util.*;
import java.util.concurrent.atomic.AtomicLong;

@Service
@AllArgsConstructor
public class TimelineService {

    private final TimelineRepository timelineRepository;

    private final TimelineMapper timelineMapper;

    private final TimelineResourceRepository timelineResourceRepository;

    @Transactional
    public TimelineDto createTimeline(Long parentTimelineId) {
        Timeline timeline;
        if (parentTimelineId == null) {
            timeline = timelineRepository.getTimelineByCommonTrue();
        } else {
            ErrorDescriptor.NOT_FOUND_TIMELINE.throwIsFalse(timelineRepository.existsById(parentTimelineId));
            ErrorDescriptor.TIMELINE_DESTROY.throwIsFalse(
                    timelineRepository.existsByDestroyedFalseAndConnectedFalseAndId(parentTimelineId)
            );
            timeline = timelineRepository.getReferenceById(parentTimelineId);
        }
        timeline = timelineRepository.save(timelineMapper.createNewTimeline(timeline));
        timelineMapper.generateResources(timeline.getId());
        return timelineMapper.convertTimelineDto(timeline);
    }

    @Transactional
    public TimelineDto createRandomTimeline() {
        Timeline timeline = timelineRepository.findRandomTimeline();
        timeline = timelineRepository.save(timelineMapper.createNewTimeline(timeline));
        timelineMapper.generateResources(timeline.getId());
        return timelineMapper.convertTimelineDto(timeline);
    }

    @Transactional
    public TimelineDto getTimeline(Long timelineId) {
        ErrorDescriptor.NOT_FOUND_TIMELINE.throwIsFalse(timelineRepository.existsById(timelineId));
        ErrorDescriptor.TIMELINE_DESTROY.throwIsFalse(
                timelineRepository.existsByDestroyedFalseAndConnectedFalseAndId(timelineId)
        );
        Timeline timeline = timelineRepository.getTimelineByDestroyedFalseAndConnectedFalseAndId(timelineId);
        return timelineMapper.convertTimelineDto(timeline);
    }

    @Transactional
    public DestroyTimelineDto destroyTimeline(Long timelineId) {
        ErrorDescriptor.NOT_FOUND_TIMELINE.throwIsFalse(timelineRepository.existsById(timelineId));
        ErrorDescriptor.TIMELINE_DESTROY.throwIsFalse(
                timelineRepository.existsByDestroyedFalseAndConnectedFalseAndId(timelineId)
        );
        Timeline timeline = timelineRepository.getTimelineByDestroyedFalseAndConnectedFalseAndId(timelineId);
        timeline.setDestroyed(true);
        DestroyTimelineDto destroyTimelineDto = timelineMapper.convertToDestroyTimelineDto(
                timelineRepository.save(timeline)
        );
        destroyTimelineDto.setDestroyedTimelines(destroyed(timeline.getChildrenTimelines()));
        return destroyTimelineDto;
    }

    @Transactional
    public ConnectedDto connected(Long connectedCount) {
        List<ConnectedTimelineDto> connectedTimeline = new ArrayList<>(Collections.emptyList());
        List<DestroyTimelineDto> destroyedTimeline = new ArrayList<>(Collections.emptyList());
        AtomicLong counter = new AtomicLong(0L);
        timelineRepository.findAllByCommonFalseAndConnectedFalseAndDestroyedFalse()
                .sorted(Comparator.comparing(Timeline::getId))
                .sorted(Comparator.comparing(timeline -> timeline.getChildrenTimelines().size()))
                .forEach(timeline -> {
                    if (counter.get() >= connectedCount && !timeline.getConnected()) {
                        timeline.setDestroyed(true);
                        DestroyTimelineDto destroyedTimelineDto = timelineMapper
                                .convertToDestroyTimelineDto(timelineRepository.save(timeline));
                        List<DestroyTimelineDto> destroyedChildren = destroyed(timeline.getChildrenTimelines());
                        destroyedTimelineDto.setDestroyedTimelines(destroyedChildren);
                        destroyedTimeline.add(destroyedTimelineDto);
                        destroyedTimeline.addAll(destroyedChildren);
                    } else {
                        timeline.setConnected(true);
                        ConnectedTimelineDto connectedTimelineDto = timelineMapper
                                .convertToConnectedTimelineDto(timelineRepository.save(timeline));
                        List<ConnectedTimelineDto> connectedChildren = connected(timeline.getChildrenTimelines());
                        connectedTimelineDto.setConnectedTimelines(connectedChildren);
                        connectedTimeline.add(connectedTimelineDto);
                        connectedTimeline.addAll(connectedChildren);
                        counter.set(counter.get() + 1L + connectedChildren.size());
                    }
                });
        return ConnectedDto.builder()
                .connectedTimeline(connectedTimeline)
                .destroyedTimeline(destroyedTimeline)
                .build();
    }

    @Transactional
    public TimelineDto robbery(Long timelineId) {
        ErrorDescriptor.NOT_FOUND_TIMELINE.throwIsFalse(timelineRepository.existsById(timelineId));
        Timeline timeline = timelineRepository.getReferenceById(timelineId);
        ErrorDescriptor.TIMELINE_DESTROY.throwIsTrue(timeline.getDestroyed());
        ErrorDescriptor.TIMELINE_COLLECTED.throwIsTrue(timeline.getConnected());
        ErrorDescriptor.TIMELINE_IS_COMMON.throwIsTrue(timeline.getCommon());
        ErrorDescriptor.TIMELINE_IS_ROBBERY.throwIsTrue(timeline.getRobbery());
        timeline.setRobbery(true);
        TimelineDto timelineDto = timelineMapper.convertTimelineDto(timelineRepository.save(timeline));
        timelineResourceRepository.findAllByTimelineResourcePk_TimelineId(timelineId).forEach(timelineResource -> {
            timelineResource.setCount(0L);
            timelineResourceRepository.save(timelineResource);
        });
        return timelineDto;
    }

    @Transactional
    public RandomTimeline getRandomTimeline() {
        List<Long> ids = timelineRepository.findAllByCommonFalseAndConnectedFalseAndDestroyedFalse()
                .map(Timeline::getId).toList();
        RandomTimeline randomTimeline = new RandomTimeline();
        if (ids.isEmpty()) {
            randomTimeline.setId(1L);
        } else {
            randomTimeline.setId(ids.get(randInt(0, ids.size() - 1)));
        }
        return randomTimeline;
    }

    @Transactional
    public List<Long> getAllTimelineIds(){
        return timelineRepository.findAllByCommonFalseAndConnectedFalseAndDestroyedFalse().map(Timeline::getId).toList();
    }

    private List<DestroyTimelineDto> destroyed(List<Timeline> timelines) {
        List<DestroyTimelineDto> destroyedTimeline = new ArrayList<>(Collections.emptyList());
        if (!timelines.isEmpty()) {
            timelines.forEach(timeline -> {
                timeline.setDestroyed(true);
                DestroyTimelineDto destroyedTimelineDto = timelineMapper.convertToDestroyTimelineDto(timelineRepository.save(timeline));
                List<DestroyTimelineDto> destroyedChildren = destroyed(timeline.getChildrenTimelines());
                destroyedTimelineDto.setDestroyedTimelines(destroyedChildren);
                destroyedTimeline.add(destroyedTimelineDto);
                destroyedTimeline.addAll(destroyedChildren);
            });
        }
        return destroyedTimeline;
    }

    private List<ConnectedTimelineDto> connected(List<Timeline> timelines) {
        List<ConnectedTimelineDto> connectedTimeline = new ArrayList<>(Collections.emptyList());
        if (!timelines.isEmpty()) {
            timelines.forEach(timeline -> {
                timeline.setConnected(true);
                ConnectedTimelineDto connectedTimelineDto = timelineMapper.convertToConnectedTimelineDto(timelineRepository.save(timeline));
                List<ConnectedTimelineDto> connectedChildren = connected(timeline.getChildrenTimelines());
                connectedTimelineDto.setConnectedTimelines(connectedChildren);
                connectedTimeline.add(connectedTimelineDto);
                connectedTimeline.addAll(connectedChildren);
            });
        }
        return connectedTimeline;
    }

    private static int randInt(int min, int max) {
        return new Random().nextInt((max - min) + 1) + min;
    }

}
