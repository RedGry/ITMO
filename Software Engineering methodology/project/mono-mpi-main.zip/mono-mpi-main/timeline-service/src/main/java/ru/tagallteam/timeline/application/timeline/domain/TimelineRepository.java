package ru.tagallteam.timeline.application.timeline.domain;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.stream.Stream;

public interface TimelineRepository extends JpaRepository<Timeline, Long> {

    Timeline getTimelineByCommonTrue();

    Boolean existsByDestroyedFalseAndConnectedFalseAndId(Long id);

    Timeline getTimelineByDestroyedFalseAndConnectedFalseAndId(Long id);

    Stream<Timeline> findAllByCommonFalseAndConnectedFalseAndDestroyedFalse();

    @Query(value = "SELECT * FROM timeline ORDER BY RANDOM() LIMIT 1", nativeQuery = true)
    Timeline findRandomTimeline();


}
