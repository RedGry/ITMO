package ru.tagallteam.timeline.application.common;

public interface Constants {
    String TIME_FORMAT = "mm:ss";
    String DATE_TIME_FORMAT = "dd.MM.yyyy HH:mm:ss";
}
