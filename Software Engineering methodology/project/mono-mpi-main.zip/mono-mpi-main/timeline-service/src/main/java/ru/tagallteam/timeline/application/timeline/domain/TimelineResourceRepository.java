package ru.tagallteam.timeline.application.timeline.domain;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.stream.Stream;

public interface TimelineResourceRepository extends JpaRepository<TimelineResource, TimelineResourcePk> {

    Stream<TimelineResource> findAllByTimelineResourcePk_TimelineId(Long timeLine);
}
