package ru.tagallteam.timeline.application.timeline.model;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class ConnectedDto {
    private List<ConnectedTimelineDto> connectedTimeline;
    private List<DestroyTimelineDto> destroyedTimeline;
}
