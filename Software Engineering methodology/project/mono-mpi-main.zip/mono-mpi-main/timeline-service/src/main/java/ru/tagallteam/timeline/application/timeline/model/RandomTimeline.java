package ru.tagallteam.timeline.application.timeline.model;

import lombok.Data;

@Data
public class RandomTimeline {
    private Long id;
}
