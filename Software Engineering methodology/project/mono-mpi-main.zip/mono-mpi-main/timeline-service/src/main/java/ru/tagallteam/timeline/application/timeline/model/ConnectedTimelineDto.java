package ru.tagallteam.timeline.application.timeline.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class ConnectedTimelineDto extends TimelineDto{
    private List<ConnectedTimelineDto> connectedTimelines;
}
