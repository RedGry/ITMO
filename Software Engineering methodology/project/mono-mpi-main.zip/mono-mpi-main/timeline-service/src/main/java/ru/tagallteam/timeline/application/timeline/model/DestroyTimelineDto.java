package ru.tagallteam.timeline.application.timeline.model;

import lombok.Data;
import lombok.EqualsAndHashCode;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
public class DestroyTimelineDto extends TimelineDto{
    private List<DestroyTimelineDto> destroyedTimelines;
}
