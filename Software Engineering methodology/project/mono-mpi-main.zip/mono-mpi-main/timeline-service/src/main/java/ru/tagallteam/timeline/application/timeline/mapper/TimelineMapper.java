package ru.tagallteam.timeline.application.timeline.mapper;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;
import ru.tagallteam.timeline.application.timeline.domain.*;
import ru.tagallteam.timeline.application.timeline.model.ConnectedTimelineDto;
import ru.tagallteam.timeline.application.timeline.model.DestroyTimelineDto;
import ru.tagallteam.timeline.application.timeline.model.ResourceDto;
import ru.tagallteam.timeline.application.timeline.model.TimelineDto;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Component
@AllArgsConstructor
public class TimelineMapper {

    private final TimelineResourceRepository timelineResourceRepository;
    private final ResourceRepository resourceRepository;

    public Timeline createNewTimeline(Timeline timeline) {
        Timeline newTimeline = new Timeline();
        newTimeline.setTimeline(timeline);
        return newTimeline;
    }

    public void generateResources(Long timelineId) {
        int countResources = (int) resourceRepository.count();
        int upperBound = randInt(1, 4);
        List<TimelineResource> timelineResources = new ArrayList<>();
        for (int i = 0; i < upperBound; i++) {
            TimelineResourcePk timelineResourcePk = new TimelineResourcePk();
            timelineResourcePk.setTimelineId(timelineId);
            timelineResourcePk.setResourceId((long) randInt(1, countResources));
            TimelineResource timelineResource = new TimelineResource();
            timelineResource.setTimelineResourcePk(timelineResourcePk);
            timelineResource.setCount((long) randInt(1, 300));
            timelineResources.add(timelineResource);
        }
        timelineResourceRepository.saveAll(timelineResources);
    }

    public TimelineDto convertTimelineDto(Timeline timeline) {
        TimelineDto timelineDto = new TimelineDto();
        timelineDto.setId(timeline.getId());
        timelineDto.setParentId(timeline.getTimeline() == null ? null : timeline.getTimeline().getId());
        timelineDto.setCommon(timeline.getCommon());
        timelineDto.setConnected(timeline.getConnected());
        timelineDto.setDestroyed(timeline.getDestroyed());
        timelineDto.setRobbery(timeline.getRobbery());
        timelineDto.setCreateTime(timeline.getCreateTime());
        timelineDto.setResources(timelineResourceRepository.findAllByTimelineResourcePk_TimelineId(timeline.getId())
                .map(timelineResource -> {
                    Resource resource = resourceRepository.getReferenceById(timelineResource.getTimelineResourcePk().getResourceId());
                    ResourceDto resourceDto = convertResourceDto(resource);
                    resourceDto.setCount(timelineResource.getCount());
                    resourceDto.setCost(resource.getCost());
                    return resourceDto;
                }).toList()
        );
        timelineDto.setCostOfResources(
                timelineDto.getResources().stream()
                        .mapToLong(resource -> resource.getCost() * resource.getCost())
                        .sum()
        );
        return timelineDto;
    }

    public DestroyTimelineDto convertToDestroyTimelineDto(Timeline timeline) {
        DestroyTimelineDto destroyTimelineDto = new DestroyTimelineDto();
        destroyTimelineDto.setId(timeline.getId());
        destroyTimelineDto.setParentId(timeline.getTimeline() == null ? null : timeline.getTimeline().getId());
        destroyTimelineDto.setCommon(timeline.getCommon());
        destroyTimelineDto.setConnected(timeline.getConnected());
        destroyTimelineDto.setDestroyed(timeline.getDestroyed());
        destroyTimelineDto.setRobbery(timeline.getRobbery());
        destroyTimelineDto.setCreateTime(timeline.getCreateTime());
        destroyTimelineDto.setResources(timelineResourceRepository.findAllByTimelineResourcePk_TimelineId(timeline.getId())
                .map(timelineResource -> {
                    Resource resource = resourceRepository.getReferenceById(timelineResource.getTimelineResourcePk().getResourceId());
                    ResourceDto resourceDto = convertResourceDto(resource);
                    resourceDto.setCount(timelineResource.getCount());
                    return resourceDto;
                }).toList()
        );
        return destroyTimelineDto;
    }

    public ConnectedTimelineDto convertToConnectedTimelineDto(Timeline timeline) {
        ConnectedTimelineDto connectedTimelineDto = new ConnectedTimelineDto();
        connectedTimelineDto.setId(timeline.getId());
        connectedTimelineDto.setParentId(timeline.getTimeline() == null ? null : timeline.getTimeline().getId());
        connectedTimelineDto.setCommon(timeline.getCommon());
        connectedTimelineDto.setConnected(timeline.getConnected());
        connectedTimelineDto.setDestroyed(timeline.getDestroyed());
        connectedTimelineDto.setRobbery(timeline.getRobbery());
        connectedTimelineDto.setCreateTime(timeline.getCreateTime());
        connectedTimelineDto.setResources(timelineResourceRepository.findAllByTimelineResourcePk_TimelineId(timeline.getId())
                .map(timelineResource -> {
                    Resource resource = resourceRepository.getReferenceById(timelineResource.getTimelineResourcePk().getResourceId());
                    ResourceDto resourceDto = convertResourceDto(resource);
                    resourceDto.setCount(timelineResource.getCount());
                    return resourceDto;
                }).toList()
        );
        return connectedTimelineDto;
    }

    public ResourceDto convertResourceDto(Resource resource) {
        ResourceDto resourceDto = new ResourceDto();
        resourceDto.setId(resource.getId());
        resourceDto.setName(resource.getName());
        resourceDto.setCost(resource.getCost());
        return resourceDto;
    }

    private static int randInt(int min, int max) {
        return new Random().nextInt((max - min) + 1) + min;
    }
}
