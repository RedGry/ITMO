rootProject.name = "machine-service"
