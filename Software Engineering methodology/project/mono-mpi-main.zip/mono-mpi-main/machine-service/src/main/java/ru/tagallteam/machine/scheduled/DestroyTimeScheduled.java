package ru.tagallteam.machine.scheduled;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.tagallteam.machine.application.machine.domain.Properties;
import ru.tagallteam.machine.application.machine.domain.PropertiesRepository;
import ru.tagallteam.machine.scheduled.domain.DestroyScheduled;
import ru.tagallteam.machine.scheduled.domain.DestroyScheduledRepository;
import ru.tagallteam.machine.scheduled.domain.DestroyScheduledType;
import ru.tagallteam.machine.scheduled.service.DestroyScheduledService;

import java.time.LocalDateTime;

@Slf4j
@Component
@RequiredArgsConstructor
public class DestroyTimeScheduled {

    private final Long MACHINE_ID = 1L;

    private final PropertiesRepository propertiesRepository;
    private final DestroyScheduledRepository destroyScheduledRepository;
    private final DestroyScheduledService destroyScheduledService;

    @Scheduled(fixedRate = 1000)
    public void destroyTimelineInQueue() {
        if (!destroyScheduledRepository.existsByEndNullAndType(DestroyScheduledType.QUEUE)) {
            destroyScheduledService.connected();
        }
    }
}
