package ru.tagallteam.machine.scheduled.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DestroyTimelineRepository extends JpaRepository<DestroyTimeline, Long> {
}
