package ru.tagallteam.machine.application.machine.model;

import lombok.Data;

/**
 * @author Iurii Babalin (ueretz)
 */
@Data
public class BufferDto {
    private Long size;
}
