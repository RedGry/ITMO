package ru.tagallteam.machine.application.machine;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.tagallteam.machine.application.machine.model.BufferDto;
import ru.tagallteam.machine.application.machine.model.TimeDto;
import ru.tagallteam.machine.application.machine.service.MachineService;

@RestController
@AllArgsConstructor
@RequestMapping("/v1/machine")
public class MachineController {

    private final MachineService machineService;

    @PutMapping("/clear/time")
    public void clearTime(@RequestParam String time) {
        machineService.clearTime(time);
    }

    @PutMapping("/buffer/size")
    public void setBufferSize(@RequestParam Long bufferSize) {
        machineService.setBufferSize(bufferSize);
    }

    @GetMapping("/time")
    public TimeDto getTime() {
        return machineService.getTime();
    }

    @GetMapping("/buffer")
    public BufferDto getBuffer() {
        return machineService.getBuffer();
    }
}
