package ru.tagallteam.machine.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xddf.usermodel.chart.AxisPosition;
import org.apache.poi.xddf.usermodel.chart.ChartTypes;
import org.apache.poi.xddf.usermodel.chart.LegendPosition;
import org.apache.poi.xddf.usermodel.chart.XDDFCategoryAxis;
import org.apache.poi.xddf.usermodel.chart.XDDFChartLegend;
import org.apache.poi.xddf.usermodel.chart.XDDFDataSource;
import org.apache.poi.xddf.usermodel.chart.XDDFDataSourcesFactory;
import org.apache.poi.xddf.usermodel.chart.XDDFLineChartData;
import org.apache.poi.xddf.usermodel.chart.XDDFNumericalDataSource;
import org.apache.poi.xddf.usermodel.chart.XDDFValueAxis;
import org.apache.poi.xssf.usermodel.XSSFChart;
import org.apache.poi.xssf.usermodel.XSSFClientAnchor;
import org.apache.poi.xssf.usermodel.XSSFDrawing;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Component;
import ru.tagallteam.machine.application.common.Constants;
import ru.tagallteam.machine.scheduled.domain.DestroyScheduled;
import ru.tagallteam.machine.scheduled.domain.DestroyScheduledRepository;

@Component
@RequiredArgsConstructor
public class XLSXReportGenerator {

    private final DestroyScheduledRepository destroyScheduledRepository;

    @Transactional
    public InputStream generateReport(LocalDate startDate, LocalDate stopDate) {
        try {
            XSSFWorkbook workbook = new XSSFWorkbook();
            // Создание листа
            XSSFSheet sheet = workbook.createSheet("Destroy Scheduled");
            // Заголовок таблицы
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("ID");
            header.createCell(1).setCellValue("Запуск станка");
            header.createCell(2).setCellValue("Остановка станка");
            header.createCell(3).setCellValue("Тип действия");
            header.createCell(4).setCellValue("Общее количество измененный ветвей");

            AtomicInteger rowNum = new AtomicInteger();

            Stream<DestroyScheduled> destroyScheduledList = destroyScheduledRepository.findAllByStartAfterAndEndBefore(
                    LocalDateTime.of(startDate, LocalTime.MIN),
                    LocalDateTime.of(stopDate, LocalTime.MAX)
            );

            Long destroyScheduledListSize = destroyScheduledRepository.countByStartAfterAndEndBefore(
                    LocalDateTime.of(startDate, LocalTime.MIN),
                    LocalDateTime.of(stopDate, LocalTime.MAX)
            );

            destroyScheduledList.forEach(destroyScheduled -> {
                Row row = sheet.createRow(rowNum.getAndIncrement());
                row.createCell(0).setCellValue(destroyScheduled.getId());
                row.createCell(1).setCellValue(destroyScheduled.getStart().format(
                        DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT)
                ));
                row.createCell(2).setCellValue(destroyScheduled.getEnd() != null ? destroyScheduled.getEnd()
                        .format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT)) : "");
                row.createCell(3).setCellValue(destroyScheduled.getType().name());
                row.createCell(4).setCellValue(destroyScheduled.getDestroyTimelines().size());
            });
            // Создание графика
            XSSFDrawing drawing = sheet.createDrawingPatriarch();
            XSSFClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 0, rowNum.get() + 2, 10, rowNum.get() + 20);

            XSSFChart chart = drawing.createChart(anchor);
            chart.setTitleText("Общее количество измененный ветвей по Запуск станка");
            chart.setTitleOverlay(false);

            XDDFChartLegend legend = chart.getOrAddLegend();
            legend.setPosition(LegendPosition.BOTTOM);

            XDDFCategoryAxis bottomAxis = chart.createCategoryAxis(AxisPosition.BOTTOM);
            bottomAxis.setTitle("Запуск станка");
            XDDFValueAxis leftAxis = chart.createValueAxis(AxisPosition.LEFT);
            leftAxis.setTitle("Общее количество измененный ветвей");

            XDDFDataSource<String> dates = XDDFDataSourcesFactory.fromStringCellRange(sheet,
                    new CellRangeAddress(1, destroyScheduledListSize.intValue(), 1, 1));
            XDDFNumericalDataSource<Double> values = XDDFDataSourcesFactory.fromNumericCellRange(sheet,
                    new CellRangeAddress(1, destroyScheduledListSize.intValue(), 4, 4));

            XDDFLineChartData data = (XDDFLineChartData) chart.createData(ChartTypes.LINE, bottomAxis, leftAxis);
            XDDFLineChartData.Series series = (XDDFLineChartData.Series) data.addSeries(dates, values);
            series.setTitle("Измененные ветви", null);
            chart.plot(data);
            // Создание байтового потока
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            workbook.write(bos);
            workbook.close();
            return new ByteArrayInputStream(bos.toByteArray());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
