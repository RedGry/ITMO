package ru.tagallteam.machine.scheduled.domain;

public enum DestroyStatus {
    DESTROYED,
    CONNECTED
}
