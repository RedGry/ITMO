package ru.tagallteam.machine.application.machine.model;

import lombok.Data;

/**
 * @author Iurii Babalin (ueretz)
 */
@Data
public class TimeDto {
    private String time;
}
