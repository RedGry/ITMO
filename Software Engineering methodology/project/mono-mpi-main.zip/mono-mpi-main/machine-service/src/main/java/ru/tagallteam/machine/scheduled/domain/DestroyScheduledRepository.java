package ru.tagallteam.machine.scheduled.domain;

import java.time.LocalDateTime;
import java.util.stream.Stream;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DestroyScheduledRepository extends JpaRepository<DestroyScheduled, Long> {
    Boolean existsByEndNullAndType(DestroyScheduledType destroyScheduledType);

    DestroyScheduled findFirstByTypeOrderByEndDesc(DestroyScheduledType type);

    Stream<DestroyScheduled> findAllByStartAfterAndEndBefore(LocalDateTime start, LocalDateTime end);
    Long countByStartAfterAndEndBefore(LocalDateTime start, LocalDateTime end);
}
