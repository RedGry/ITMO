package ru.tagallteam.machine.application.machine.service;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;
import ru.tagallteam.machine.application.machine.domain.Properties;
import ru.tagallteam.machine.application.machine.domain.PropertiesRepository;
import ru.tagallteam.machine.application.machine.model.BufferDto;
import ru.tagallteam.machine.application.machine.model.TimeDto;
import ru.tagallteam.machine.error.ErrorDescriptor;

import java.time.Duration;
import java.time.format.DateTimeParseException;

@Service
@AllArgsConstructor
public class MachineService {

    private final Long MACHINE_ID = 1L;

    private final PropertiesRepository propertiesRepository;

    public void clearTime(String time) {
        Duration duration;
        try {
            duration = Duration.parse("PT".concat(time.toUpperCase()));
        } catch (DateTimeParseException parseException) {
            throw ErrorDescriptor.BAD_TIME_TYPE.callExceptionModel();
        }
        Properties properties = propertiesRepository.getReferenceById(MACHINE_ID);
        properties.setDeltaClearTime(duration.getSeconds());
        propertiesRepository.save(properties);
    }

    public void setBufferSize(Long bufferSize) {
        Properties properties = propertiesRepository.getReferenceById(MACHINE_ID);
        properties.setBufferSize(bufferSize);
        propertiesRepository.save(properties);
    }

    public TimeDto getTime() {
        Properties properties = propertiesRepository.getReferenceById(MACHINE_ID);
        TimeDto timeDto = new TimeDto();
        timeDto.setTime(properties.getDeltaClearTime().toString().concat("s"));
        return timeDto;
    }

    public BufferDto getBuffer() {
        Properties properties = propertiesRepository.getReferenceById(MACHINE_ID);
        BufferDto bufferDto = new BufferDto();
        bufferDto.setSize(properties.getBufferSize());
        return bufferDto;
    }
}
