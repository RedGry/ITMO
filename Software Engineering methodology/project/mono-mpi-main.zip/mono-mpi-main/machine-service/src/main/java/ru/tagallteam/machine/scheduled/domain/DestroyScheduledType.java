package ru.tagallteam.machine.scheduled.domain;

public enum DestroyScheduledType {
    TIME,
    QUEUE
}
