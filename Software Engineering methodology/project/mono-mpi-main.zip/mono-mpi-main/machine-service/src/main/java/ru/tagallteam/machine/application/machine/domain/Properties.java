package ru.tagallteam.machine.application.machine.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@Entity
@ToString(of = "id")
@Table(name = "properties")
public class Properties {
    @Id
    private Long id;
    @Column(name = "buffer_size")
    private Long bufferSize;
    @Column(name = "delta_clear_time")
    private Long deltaClearTime;
}
