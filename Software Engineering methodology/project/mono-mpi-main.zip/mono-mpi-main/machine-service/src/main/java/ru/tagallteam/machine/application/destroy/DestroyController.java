package ru.tagallteam.machine.application.destroy;

import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.DeleteMapping;
import ru.tagallteam.machine.application.destroy.service.DestroyService;

@RestController
@AllArgsConstructor
@RequestMapping("/v1/destroy")
public class DestroyController {

    private final DestroyService destroyService;

    @PutMapping
    public void addDestroyQueue(@RequestParam Long timelineId) {
        destroyService.addDestroyQueue(timelineId);
    }

    @DeleteMapping
    public void allDestroyQueue() {
        destroyService.allDestroyQueue();
    }
}
