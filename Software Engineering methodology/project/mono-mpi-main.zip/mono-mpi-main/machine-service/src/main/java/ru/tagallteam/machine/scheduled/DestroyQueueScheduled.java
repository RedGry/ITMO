package ru.tagallteam.machine.scheduled;

import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import ru.tagallteam.machine.scheduled.domain.DestroyScheduledRepository;
import ru.tagallteam.machine.scheduled.domain.DestroyScheduledType;
import ru.tagallteam.machine.scheduled.service.DestroyScheduledService;

@Component
@RequiredArgsConstructor
public class DestroyQueueScheduled {
    private final DestroyScheduledRepository destroyScheduledRepository;
    private final DestroyScheduledService destroyScheduledService;

    @Scheduled(fixedRate = 1000)
    public void destroyTimelineInQueue() {
        if (!destroyScheduledRepository.existsByEndNullAndType(DestroyScheduledType.TIME)) {
            destroyScheduledService.destroy();
        }
    }
}
