package ru.tagallteam.machine.application.report;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.apache.commons.io.Charsets;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ru.tagallteam.machine.application.common.Constants;
import ru.tagallteam.machine.error.ErrorDescriptor;
import ru.tagallteam.machine.utils.XLSXReportGenerator;

/**
 * @author Iurii Babalin (ueretz)
 */
@RestController
@RequiredArgsConstructor
@RequestMapping("/v1/report")
public class ReportController {

    private final XLSXReportGenerator xlsxReportGenerator;

    @GetMapping("/graphic")
    public void downloadGraphic(
            @RequestParam
            @DateTimeFormat(pattern = "dd.MM.yyyy")
            LocalDate start,
            @RequestParam
            @DateTimeFormat(pattern = "dd.MM.yyyy")
            LocalDate stop,
            HttpServletResponse httpServletResponse
    ) {
        setHeaders(httpServletResponse, "Отчет_о_работе_станка");
        try {
            httpServletResponse.getOutputStream().write(xlsxReportGenerator.generateReport(start, stop).readAllBytes());
            httpServletResponse.setStatus(HttpStatus.OK.value());
        } catch (IOException e) {
            ErrorDescriptor.REPORT_CREATE_ERROR.exception();
        }
    }

    private void setHeaders(HttpServletResponse response, String fileName) {
        var contentDisposition = ContentDisposition.builder("attachment")
                .filename(fileName.concat("_").concat(
                        LocalDateTime.now().format(DateTimeFormatter.ofPattern(Constants.DATE_TIME_FORMAT))
                ).concat(".xlsx"), Charsets.UTF_8)
                .build()
                .toString()
                .replace("UTF-8''", "");
        response.addHeader(HttpHeaders.CONTENT_DISPOSITION, contentDisposition);
        response.addHeader(
                HttpHeaders.CONTENT_TYPE,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        );
        response.addHeader(HttpHeaders.ACCESS_CONTROL_EXPOSE_HEADERS, contentDisposition);
        response.setStatus(HttpStatus.OK.value());
    }
}
