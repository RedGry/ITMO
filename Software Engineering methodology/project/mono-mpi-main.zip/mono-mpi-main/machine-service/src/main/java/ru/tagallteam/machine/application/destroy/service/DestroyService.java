package ru.tagallteam.machine.application.destroy.service;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import ru.tagallteam.machine.application.destroy.domain.DestroyQueue;
import ru.tagallteam.machine.application.destroy.domain.DestroyQueueRepository;
import ru.tagallteam.machine.configuration.timeline.service.TimelineService;

import java.util.List;

@Service
@RequiredArgsConstructor
public class DestroyService {
    private final DestroyQueueRepository destroyQueueRepository;

    private final TimelineService timelineService;

    public void addDestroyQueue(Long timelineId) {
        if (!destroyQueueRepository.existsByTimelineId(timelineId)) {
            DestroyQueue destroyQueue = new DestroyQueue();
            destroyQueue.setTimelineId(timelineId);
            destroyQueueRepository.save(destroyQueue);
        }
    }

    public void allDestroyQueue() {
        List<DestroyQueue> destroyQueueList = timelineService.getAllTimelineIds()
                .parallelStream()
                .filter(timelineId -> !destroyQueueRepository.existsByTimelineId(timelineId))
                .map(timelineId -> {
                    DestroyQueue destroyQueue = new DestroyQueue();
                    destroyQueue.setTimelineId(timelineId);
                    return destroyQueue;
                }).toList();
        destroyQueueRepository.saveAll(destroyQueueList);
    }
}
