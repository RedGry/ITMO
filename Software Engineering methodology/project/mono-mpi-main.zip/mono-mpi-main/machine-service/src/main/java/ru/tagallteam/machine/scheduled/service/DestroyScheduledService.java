package ru.tagallteam.machine.scheduled.service;

import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Component;
import ru.tagallteam.machine.application.destroy.domain.DestroyQueue;
import ru.tagallteam.machine.application.destroy.domain.DestroyQueueRepository;
import ru.tagallteam.machine.application.machine.domain.Properties;
import ru.tagallteam.machine.application.machine.domain.PropertiesRepository;
import ru.tagallteam.machine.configuration.timeline.model.ConnectedDto;
import ru.tagallteam.machine.configuration.timeline.model.TimelineDto;
import ru.tagallteam.machine.configuration.timeline.service.TimelineService;
import ru.tagallteam.machine.scheduled.domain.*;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Component
@RequiredArgsConstructor
public class DestroyScheduledService {

    private final Long MACHINE_ID = 1L;

    private final TimelineService timelineService;

    private final DestroyQueueRepository destroyQueueRepository;

    private final DestroyTimelineRepository destroyTimelineRepository;

    private final PropertiesRepository propertiesRepository;

    private final DestroyScheduledRepository destroyScheduledRepository;

    @Transactional
    public void destroy() {
        Properties properties = propertiesRepository.getReferenceById(MACHINE_ID);
        Pageable pageable = PageRequest.of(0, properties.getBufferSize().intValue());
        List<DestroyQueue> queueList = destroyQueueRepository.findAll(pageable).toList();
        if (!queueList.isEmpty()) {
            log.info("destroy timelines: {}", queueList.size());
            DestroyScheduled destroyScheduled = initDestroy(DestroyScheduledType.QUEUE);
            queueList.forEach(destroyQueue -> {
                try {
                    TimelineDto timeline = timelineService.destroyTimeline(destroyQueue.getTimelineId());
                    saveStatistic(timeline.getId(), DestroyStatus.DESTROYED, destroyScheduled);
                } catch (Exception ex) {
                    log.error("DestroyService: {}", ex.getMessage());
                } finally {
                    destroyQueueRepository.deleteAllByTimelineId(destroyQueue.getTimelineId());
                }
            });
            destroyScheduled.setEnd(LocalDateTime.now());
            destroyScheduledRepository.save(destroyScheduled);
        }
    }

    @Transactional
    public void connected() {
        Properties properties = propertiesRepository.getReferenceById(MACHINE_ID);
        DestroyScheduled lastDestroyScheduled = destroyScheduledRepository
                .findFirstByTypeOrderByEndDesc(DestroyScheduledType.TIME);
        if (lastDestroyScheduled == null) {
            log.info("connected timelines: {}", properties.getBufferSize());
            DestroyScheduled destroyScheduled = initDestroy(DestroyScheduledType.TIME);
            destroyScheduled.setEnd(LocalDateTime.now());
            destroyScheduledRepository.save(destroyScheduled);
        } else {
            if (lastDestroyScheduled.getEnd().plusSeconds(properties.getDeltaClearTime())
                    .isBefore(LocalDateTime.now())
            ) {
                log.info("connected timelines: {}", properties.getBufferSize());
                DestroyScheduled destroyScheduled = initDestroy(DestroyScheduledType.TIME);
                initConnectedTimelines(properties, destroyScheduled);
                destroyScheduled.setEnd(LocalDateTime.now());
                destroyScheduledRepository.save(destroyScheduled);
            }
        }
    }

    private void initConnectedTimelines(Properties properties, DestroyScheduled destroyScheduled) {
        ConnectedDto connectedDto = timelineService.connected(properties.getBufferSize());
        connectedDto.getConnectedTimeline().forEach(timeline -> {
            saveStatistic(timeline.getId(), DestroyStatus.CONNECTED, destroyScheduled);
        });
        connectedDto.getDestroyedTimeline().forEach(timeline -> {
            saveStatistic(timeline.getId(), DestroyStatus.DESTROYED, destroyScheduled);
        });
    }

    private DestroyScheduled initDestroy(DestroyScheduledType type) {
        DestroyScheduled destroyScheduled = new DestroyScheduled();
        destroyScheduled.setStart(LocalDateTime.now());
        destroyScheduled.setType(type);
        return destroyScheduledRepository.save(destroyScheduled);
    }

    private void saveStatistic(Long timeline, DestroyStatus status, DestroyScheduled destroyScheduled) {
        DestroyTimeline destroyTimeline = new DestroyTimeline();
        destroyTimeline.setTimelineId(timeline);
        destroyTimeline.setStatus(status);
        destroyTimeline.setDestroyScheduled(destroyScheduled);
        destroyTimelineRepository.save(destroyTimeline);
    }
}
