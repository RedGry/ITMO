package ru.tagallteam.machine.application.common;

public interface Constants {
    String TIME_FORMAT = "HH:mm:ss";
    String DATE_TIME_FORMAT = "dd.MM.yyyy HH:mm:ss";
}
