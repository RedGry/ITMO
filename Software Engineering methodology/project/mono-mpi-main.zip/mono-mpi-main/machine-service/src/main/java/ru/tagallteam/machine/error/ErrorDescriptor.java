package ru.tagallteam.machine.error;

import lombok.AllArgsConstructor;
import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.util.ObjectUtils;
import ru.tagallteam.machine.error.exception.ApplicationException;
import ru.tagallteam.machine.error.model.ApplicationError;

@Getter
@AllArgsConstructor
public enum ErrorDescriptor {

    BAD_TIME_TYPE("Параметр времени введен не корректно. Введите пожалуста цифру и тип (D,H,M,S)", HttpStatus.BAD_REQUEST),
    REPORT_CREATE_ERROR("Ошибка в формировании отчета", HttpStatus.BAD_REQUEST),
    DATA_BASE_ERROR("Ошибка взаимодействия с бд", HttpStatus.BAD_REQUEST),
    INTERNAL_SERVER_ERROR("Неожиданная ошибка сервиса", HttpStatus.INTERNAL_SERVER_ERROR),
    NOT_FOUND("Запрошенный ресурс (интерфейс) не существует", HttpStatus.NOT_FOUND);


    private final String message;


    private final HttpStatus status;

    public void exception() {
        throw ApplicationException.of(applicationError());
    }

    public ApplicationException callExceptionModel() {
        return ApplicationException.of(applicationError());
    }

    public void throwIsTrue(Boolean flag) {
        if (flag) {
            exception();
        }
    }

    public void throwIsFalse(Boolean flag) {
        if (!flag) {
            exception();
        }
    }

    public void throwIsNull(Object object) {
        if (ObjectUtils.isEmpty(object)) {
            exception();
        }
    }

    public ApplicationError applicationError() {
        return new ApplicationError(this.message, this.status);
    }

}
