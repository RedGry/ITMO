package ru.tagallteam.machine.configuration.timeline.model;

import lombok.Data;

@Data
public class RandomTimeline {
    private Long id;
}
