package ru.tagallteam.machine.application.destroy.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface DestroyQueueRepository extends JpaRepository<DestroyQueue, Long> {
    Boolean existsByTimelineId(Long timelineId);
    void deleteAllByTimelineId(Long timelineId);
}
