package ru.tagallteam.machine.application.machine.domain;

import org.springframework.data.jpa.repository.JpaRepository;

public interface PropertiesRepository extends JpaRepository<Properties, Long> {
}
