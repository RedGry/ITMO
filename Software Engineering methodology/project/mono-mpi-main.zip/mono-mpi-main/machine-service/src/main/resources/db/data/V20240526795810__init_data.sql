insert into properties(id, buffer_size, delta_clear_time)
values (1, 5, 10000)

