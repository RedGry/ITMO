create table properties
(
    id               int primary key,
    buffer_size      int not null,
    delta_clear_time int not null
);

create sequence queue_to_destroy_timeline_seq;

create table queue_to_destroy_timeline
(
    id          int primary key,
    timeline_id int not null
);

create sequence destroy_scheduled_seq;

create table destroy_scheduled
(
    id         int primary key,
    start_time timestamp   not null default now(),
    end_time   timestamp,
    type       varchar(64) not null
);

create sequence destroy_timeline_seq;

create table destroy_timeline
(
    id                   int primary key,
    destroy_scheduled_id int references destroy_scheduled (id),
    timeline_id          int         not null,
    status               varchar(64) not null
);


