plugins {
    id("java")
}

group = "ru.tagallteam"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
    mavenLocal()
}

tasks.getByName<Test>("test") {
    useJUnitPlatform()
}